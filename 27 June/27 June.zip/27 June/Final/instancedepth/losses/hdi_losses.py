"""
Losses for the Holistic Depth Initialization stage.

    SigLogLoss: scale-invariant logarithmic loss (Eigne et al.[16]), the same SigLogLoss used in eq. 10
    of the paper, applied here to the dense holistic depth.
    range_segmentation_loss: cross-entropy that supervises the range-seg head S against GT depth
    quantized into rd bins

Paper Specified:
Siglog loss is referenced (Eq. 10, ref [16])

Strongly Inferred:
The range-seg head benefits from explicit supervision via the GT depth bin index; without it S is 
under-constrained. This is the natural training signal for a "depth range segmentation".
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

class SigLogLoss(nn.Module):
    """
    Scale-invariant log loss
    
    L=(1/n)*sum(g^2)-(lambda/n^2)*(sum g)^2, g=log(pred)-log(gt)
    """

    def __init__(self, variance_focus: float=0.85, eps: float=1e-6) -> None:
        super().__init__()
        self.variance_focus=variance_focus
        self.eps=eps

    def forward(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        mask: Optional[torch.Tensor]=None,
    ) -> torch.Tensor:
        if mask is None: 
            mask=target>0
        mask=mask&(pred>0)
        pred_v=pred[mask].clamp_min(self.eps)
        tgt_v=target[mask].clamp_min(self.eps)
        if pred_v.numel()==0:
            return pred.sum()*0.0
        g=torch.log(pred_v)-torch.log(tgt_v)
        n=g.numel()
        loss=(g**2).mean()-self.variance_focus*(g.sum()**2)/(n*n)
        return torch.sqrt(loss.clamp_min(self.eps))*10.0
    
def range_segmentation_loss(
    range_logits: torch.Tensor,
    gt_depth: torch.Tensor,
    max_depth: float,
    num_ranges: int,
    ignore_index: int=-100,
) -> torch.Tensor:
    """
    Cross-entropy on range-seg logits vs quantized GT depth bins

    range_logits : (B,rd,h,w)
    gt_depth     : (B,1,H,W) metric depth: resized to (h,w) for supervision
    """

    b,rd,h,w=range_logits.shape
    gt=F.interpolate(gt_depth,size=(h,w), mode="nearest")   #(B,1,h,w)
    step=max_depth/num_ranges
    bin_idx=torch.clamp((gt/step).long(),0,num_ranges-1)    #(B,1,h,w)
    bin_idx=bin_idx.squeeze(1)
    invalid=(gt.squeeze(1)<=0)
    bin_idx=bin_idx.masked_fill(invalid,ignore_index)
    return F.cross_entropy(range_logits, bin_idx, ignore_index=ignore_index)