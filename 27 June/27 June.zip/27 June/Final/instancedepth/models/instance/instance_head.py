"""Instance Depth Layer head (InstanceDepth Sec. 4.2.1, Fig. 7).

A Mask2Former-based decoder predicts, for a fixed set of N queries, an instance
mask (Msk), a category (Cls) and an instance depth layer (Dep). Two task-specific
query streams (mask, depth) run through a shared transformer decoder; a query
fusion module then turns the paired (mask, depth) queries into the per-instance
depth layer. The mask/class predictions come solely from the mask stream
(transformer_decoder enforces this), so the depth stream cannot degrade masks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn

from .pixel_decoder import PixelDecoder, build_2d_sincos_pos_embed
from .query_fusion import QueryFusion
from .transformer_decoder import TransformerDecoder


@dataclass
class InstanceHeadConfig:
    in_channels: int = 256
    hidden_dim: int = 256
    num_queries: int = 32
    num_classes: int = 1
    num_transformer_feats: int = 3   # multi-scale maps fed to the decoder (M2F: 3)
    num_decoder_layers: int = 9      # M2F default: 3 scales x 3 = 9
    num_heads: int = 8
    ffn_hidden: int = 2048
    dropout: float = 0.0             # M2F removes dropout
    enc_layers: int = 6              # MSDeformAttn pixel-decoder encoder layers (M2F: 6)
    max_depth: float = 10.0
    mask_threshold: float = 0.5


class InstanceDepthLayerHead(nn.Module):
    def __init__(self, cfg: InstanceHeadConfig) -> None:
        super().__init__()
        self.cfg = cfg
        c = cfg.hidden_dim

        self.pixel_decoder = PixelDecoder(
            in_channels=cfg.in_channels, hidden_dim=c,
            num_transformer_feats=cfg.num_transformer_feats,
            enc_layers=cfg.enc_layers, n_heads=cfg.num_heads,
        )

        # task-specific learnable query features + their own positional embeddings
        self.mask_query_feat = nn.Embedding(cfg.num_queries, c)
        self.depth_query_feat = nn.Embedding(cfg.num_queries, c)
        self.mask_query_pos = nn.Embedding(cfg.num_queries, c)
        self.depth_query_pos = nn.Embedding(cfg.num_queries, c)

        self.transformer = TransformerDecoder(
            hidden_dim=c, num_heads=cfg.num_heads, num_layers=cfg.num_decoder_layers,
            ffn_hidden=cfg.ffn_hidden, dropout=cfg.dropout, mask_threshold=cfg.mask_threshold)
        self.query_fusion = QueryFusion(c)

        # prediction heads (used by the decoder via _predictor for the mask stream)
        self.decoder_norm = nn.LayerNorm(c)
        self.class_head = nn.Linear(c, cfg.num_classes + 1)        # +1 no-object
        self.mask_embed = nn.Sequential(
            nn.Linear(c, c), nn.ReLU(inplace=True),
            nn.Linear(c, c), nn.ReLU(inplace=True), nn.Linear(c, c))
        self.depth_head = nn.Sequential(
            nn.Linear(c, c), nn.ReLU(inplace=True), nn.Linear(c, 1))

    # ----- predictor: (N,B,C) mask-stream queries -> mask logits + class logits -----
    def _predictor(self, query: torch.Tensor, mask_features: torch.Tensor
                   ) -> Tuple[torch.Tensor, torch.Tensor]:
        q = self.decoder_norm(query).permute(1, 0, 2)              # (B,N,C)
        class_logits = self.class_head(q)                          # (B,N,K+1)
        mask_emb = self.mask_embed(q)                              # (B,N,C)
        mask_logits = torch.einsum("bnc,bchw->bnhw", mask_emb, mask_features)
        return mask_logits, class_logits

    # ----------------------------------------------------------------- forward
    def forward(
        self,
        decoder_feats: List[torch.Tensor],          # [f8,f4,f2], coarse->fine
        init_depth: Optional[torch.Tensor] = None,  # (B,1,H,W) HDI prior (unused here)
    ) -> Dict[str, object]:
        b = decoder_feats[0].shape[0]
        device, dtype = decoder_feats[0].device, decoder_feats[0].dtype

        mask_features, ms_feats = self.pixel_decoder(decoder_feats)
        ms_pos = [
            build_2d_sincos_pos_embed(f.shape[1], f.shape[2], f.shape[3], device, dtype).expand(b, -1, -1, -1)
            for f in ms_feats
        ]

        mask_q = self.mask_query_feat.weight.unsqueeze(1).repeat(1, b, 1)    # (N,B,C)
        depth_q = self.depth_query_feat.weight.unsqueeze(1).repeat(1, b, 1)
        mask_p = self.mask_query_pos.weight.unsqueeze(1).repeat(1, b, 1)
        depth_p = self.depth_query_pos.weight.unsqueeze(1).repeat(1, b, 1)

        predictions, final_mask_q, final_depth_q = self.transformer(
            mask_q, depth_q, mask_p, depth_p, ms_feats, ms_pos, mask_features, self._predictor)

        # depth layer from the fused (mask + depth) queries (Fig. 7 query fusion)
        fused = self.query_fusion(final_mask_q, final_depth_q)              # (N,B,C)
        depth_layer = torch.sigmoid(
            self.depth_head(fused.permute(1, 0, 2))) * self.cfg.max_depth   # (B,N,1)

        # mask/class from the final + per-layer mask-stream predictions
        final_mask_logits, final_class_logits = predictions[-1]
        aux = [{"pred_masks": p[0], "pred_logits": p[1]} for p in predictions[:-1]]

        return {
            "pred_masks": final_mask_logits,        # (B,N,Hf,Wf)
            "pred_logits": final_class_logits,      # (B,N,K+1)
            "pred_depth": depth_layer,              # (B,N,1)
            "mask_features": mask_features,         # (B,C,Hf,Wf)
            "aux_outputs": aux,                     # per-layer for deep supervision
        }
