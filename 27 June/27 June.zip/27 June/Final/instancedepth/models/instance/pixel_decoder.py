"""Mask2Former MSDeformAttn pixel decoder.

Replaces the previous plain-FPN pixel decoder. It follows Mask2Former's
`MSDeformAttnPixelDecoder` (Cheng et al. [12], M2F paper Sec. 3.2.2): a
multi-scale deformable-attention encoder mixes information across scales, then an
FPN path lifts the result to high-resolution per-pixel mask features.

Design (adapted to the DINOv2 + DPT backbone, which emits f8/f4/f2 at 1/8,1/4,1/2)
    * Deformable encoder runs on COARSE levels {1/8, 1/16, 1/32}. DINOv2 is
      single-scale, so 1/16 and 1/32 are produced by strided convs from f8. These
      coarse levels are also what the transformer decoder cross-attends to (M2F
      feeds the decoder 1/8,1/16,1/32 -- never 1/2 -- which keeps attention cheap).
    * High-resolution 1/2 mask features come from an FPN that fuses the encoder
      output with the crisp backbone features f4 (1/4) and f2 (1/2), WITHOUT
      attention. Masks are a cheap dot-product against these features.

The deformable attention core is the standard pure-PyTorch implementation from
Deformable DETR (grid_sample per level); no custom CUDA op is required.

forward(feats=[f8,f4,f2]) -> (mask_features (B,C,H/2,W/2), ms_feats: list, low-res first)
"""

from __future__ import annotations

import math
from typing import List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
#  positional embedding (also used by the transformer decoder)
# --------------------------------------------------------------------------- #
def build_2d_sincos_pos_embed(c: int, h: int, w: int, device, dtype) -> torch.Tensor:
    """Return (1, C, H, W) sinusoidal position embedding."""
    assert c % 4 == 0, "channels must be divisible by 4 for 2D sincos pos embed"
    y = torch.arange(h, device=device, dtype=dtype)
    x = torch.arange(w, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(y, x, indexing="ij")
    quarter = c // 4
    omega = torch.arange(quarter, device=device, dtype=dtype) / quarter
    omega = 1.0 / (10000 ** omega)
    out_x = xx.flatten()[:, None] * omega[None, :]
    out_y = yy.flatten()[:, None] * omega[None, :]
    pe = torch.cat([out_x.sin(), out_x.cos(), out_y.sin(), out_y.cos()], dim=1)   # (HW,C)
    return pe.transpose(0, 1).reshape(1, c, h, w)


# --------------------------------------------------------------------------- #
#  multi-scale deformable attention (pure PyTorch, Deformable DETR core)
# --------------------------------------------------------------------------- #
def _ms_deform_attn_core(
    value: torch.Tensor,                 # (N, Lv, n_heads, head_dim)
    spatial_shapes: List[Tuple[int, int]],
    sampling_locations: torch.Tensor,    # (N, Lq, n_heads, n_levels, n_points, 2)
    attention_weights: torch.Tensor,     # (N, Lq, n_heads, n_levels, n_points)
) -> torch.Tensor:
    n, _, n_heads, head_dim = value.shape
    _, lq, _, n_levels, n_points, _ = sampling_locations.shape
    value_list = value.split([h * w for h, w in spatial_shapes], dim=1)
    sampling_grids = 2 * sampling_locations - 1
    out = []
    for lvl, (h, w) in enumerate(spatial_shapes):
        # (N, H*W, n_heads, head_dim) -> (N*n_heads, head_dim, H, W)
        v = value_list[lvl].flatten(2).transpose(1, 2).reshape(n * n_heads, head_dim, h, w)
        # (N, Lq, n_heads, n_points, 2) -> (N*n_heads, Lq, n_points, 2)
        grid = sampling_grids[:, :, :, lvl].transpose(1, 2).flatten(0, 1)
        s = F.grid_sample(v, grid, mode="bilinear", padding_mode="zeros", align_corners=False)
        out.append(s)                                          # (N*n_heads, head_dim, Lq, n_points)
    attn = attention_weights.transpose(1, 2).reshape(n * n_heads, 1, lq, n_levels * n_points)
    output = (torch.stack(out, dim=-2).flatten(-2) * attn).sum(-1)   # (N*n_heads, head_dim, Lq)
    return output.view(n, n_heads * head_dim, lq).transpose(1, 2).contiguous()


class MSDeformAttn(nn.Module):
    """Multi-scale deformable attention (Deformable DETR / Mask2Former)."""

    def __init__(self, d_model: int = 256, n_levels: int = 3, n_heads: int = 8, n_points: int = 4) -> None:
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        self.d_model, self.n_levels, self.n_heads, self.n_points = d_model, n_levels, n_heads, n_points
        self.head_dim = d_model // n_heads
        self.sampling_offsets = nn.Linear(d_model, n_heads * n_levels * n_points * 2)
        self.attention_weights = nn.Linear(d_model, n_heads * n_levels * n_points)
        self.value_proj = nn.Linear(d_model, d_model)
        self.output_proj = nn.Linear(d_model, d_model)
        self._reset_parameters()

    def _reset_parameters(self) -> None:
        nn.init.constant_(self.sampling_offsets.weight, 0.0)
        thetas = torch.arange(self.n_heads, dtype=torch.float32) * (2.0 * math.pi / self.n_heads)
        grid = torch.stack([thetas.cos(), thetas.sin()], -1)          # (n_heads, 2)
        grid = (grid / grid.abs().max(-1, keepdim=True)[0])
        grid = grid.view(self.n_heads, 1, 1, 2).repeat(1, self.n_levels, self.n_points, 1)
        for i in range(self.n_points):
            grid[:, :, i, :] *= i + 1
        with torch.no_grad():
            self.sampling_offsets.bias = nn.Parameter(grid.view(-1))
        nn.init.constant_(self.attention_weights.weight, 0.0)
        nn.init.constant_(self.attention_weights.bias, 0.0)
        nn.init.xavier_uniform_(self.value_proj.weight); nn.init.constant_(self.value_proj.bias, 0.0)
        nn.init.xavier_uniform_(self.output_proj.weight); nn.init.constant_(self.output_proj.bias, 0.0)

    def forward(self, query, reference_points, value, spatial_shapes):
        n, lq, _ = query.shape
        n, lv, _ = value.shape
        value = self.value_proj(value).view(n, lv, self.n_heads, self.head_dim)
        offsets = self.sampling_offsets(query).view(
            n, lq, self.n_heads, self.n_levels, self.n_points, 2)
        attn = self.attention_weights(query).view(
            n, lq, self.n_heads, self.n_levels * self.n_points)
        attn = attn.softmax(-1).view(n, lq, self.n_heads, self.n_levels, self.n_points)
        # reference_points (N, Lq, n_levels, 2) in (x, y); normalizer is (W, H) per level
        normalizer = torch.as_tensor(
            [[w, h] for h, w in spatial_shapes], device=query.device, dtype=query.dtype)
        sampling_locations = (
            reference_points[:, :, None, :, None, :]
            + offsets / normalizer[None, None, None, :, None, :])
        out = _ms_deform_attn_core(value, spatial_shapes, sampling_locations, attn)
        return self.output_proj(out)


# --------------------------------------------------------------------------- #
#  deformable encoder
# --------------------------------------------------------------------------- #
class _DeformEncoderLayer(nn.Module):
    def __init__(self, d_model: int, n_levels: int, n_heads: int, n_points: int, ffn_hidden: int) -> None:
        super().__init__()
        self.self_attn = MSDeformAttn(d_model, n_levels, n_heads, n_points)
        self.norm1 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, ffn_hidden), nn.ReLU(inplace=True), nn.Linear(ffn_hidden, d_model))
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, src, pos, reference_points, spatial_shapes):
        src2 = self.self_attn(src + pos, reference_points, src, spatial_shapes)
        src = self.norm1(src + src2)
        src = self.norm2(src + self.ffn(src))
        return src


class _DeformEncoder(nn.Module):
    def __init__(self, num_layers, d_model, n_levels, n_heads, n_points, ffn_hidden) -> None:
        super().__init__()
        self.layers = nn.ModuleList(
            [_DeformEncoderLayer(d_model, n_levels, n_heads, n_points, ffn_hidden)
             for _ in range(num_layers)])

    @staticmethod
    def reference_points(spatial_shapes, device, dtype, n) -> torch.Tensor:
        refs = []
        for (h, w) in spatial_shapes:
            ry, rx = torch.meshgrid(
                torch.linspace(0.5, h - 0.5, h, device=device, dtype=dtype),
                torch.linspace(0.5, w - 0.5, w, device=device, dtype=dtype), indexing="ij")
            refs.append(torch.stack([rx.reshape(-1) / w, ry.reshape(-1) / h], -1))  # (HW,2) as (x,y)
        ref = torch.cat(refs, 0)                                  # (sumHW, 2)
        n_levels = len(spatial_shapes)
        return ref[None, :, None, :].repeat(n, 1, n_levels, 1)    # (N, sumHW, n_levels, 2)

    def forward(self, src, pos, spatial_shapes):
        n = src.shape[0]
        ref = self.reference_points(spatial_shapes, src.device, src.dtype, n)
        for layer in self.layers:
            src = layer(src, pos, ref, spatial_shapes)
        return src


# --------------------------------------------------------------------------- #
#  pixel decoder
# --------------------------------------------------------------------------- #
class PixelDecoder(nn.Module):
    """MSDeformAttn pixel decoder: deformable encoder + FPN mask features."""

    def __init__(
        self,
        in_channels: int,
        hidden_dim: int = 256,
        num_transformer_feats: int = 3,
        enc_layers: int = 6,
        n_heads: int = 8,
        n_points: int = 4,
        ffn_hidden: int = 1024,
    ) -> None:
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_transformer_feats = num_transformer_feats
        self.n_enc_levels = 3                          # {1/8, 1/16, 1/32}

        # project f8 to hidden_dim, then synthesize the two coarser encoder levels
        self.input_proj = nn.Sequential(
            nn.Conv2d(in_channels, hidden_dim, kernel_size=1), nn.GroupNorm(32, hidden_dim))
        self.down16 = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, stride=2, padding=1),
            nn.GroupNorm(32, hidden_dim), nn.GELU())
        self.down32 = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, stride=2, padding=1),
            nn.GroupNorm(32, hidden_dim), nn.GELU())
        self.level_embed = nn.Parameter(torch.zeros(self.n_enc_levels, hidden_dim))
        nn.init.normal_(self.level_embed, std=0.02)

        self.encoder = _DeformEncoder(
            enc_layers, hidden_dim, self.n_enc_levels, n_heads, n_points, ffn_hidden)

        # FPN to high-res mask features using the crisp backbone f4 (1/4), f2 (1/2)
        self.mask_lat4 = nn.Conv2d(in_channels, hidden_dim, kernel_size=1)
        self.mask_lat2 = nn.Conv2d(in_channels, hidden_dim, kernel_size=1)
        self.mask_conv4 = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(32, hidden_dim), nn.GELU())
        self.mask_conv2 = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(32, hidden_dim), nn.GELU())
        self.mask_proj = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=1)

    def forward(self, feats: List[torch.Tensor]) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        f8, f4, f2 = feats[0], feats[1], feats[2]
        device, dtype = f8.device, f8.dtype
        b = f8.shape[0]

        # ---- build the 3 coarse encoder levels {1/8, 1/16, 1/32} ----
        e8 = self.input_proj(f8)
        e16 = self.down16(e8)
        e32 = self.down32(e16)
        levels = [e8, e16, e32]
        spatial_shapes = [(lv.shape[-2], lv.shape[-1]) for lv in levels]

        # ---- flatten + add (sine + level) positional embedding ----
        src_flat, pos_flat = [], []
        for lvl, fmap in enumerate(levels):
            h, w = fmap.shape[-2:]
            src_flat.append(fmap.flatten(2).transpose(1, 2))           # (B, HW, C)
            pe = build_2d_sincos_pos_embed(self.hidden_dim, h, w, device, dtype)
            pe = pe.flatten(2).transpose(1, 2).expand(b, -1, -1)        # (B, HW, C)
            pos_flat.append(pe + self.level_embed[lvl].view(1, 1, -1))
        src = torch.cat(src_flat, dim=1)                               # (B, sumHW, C)
        pos = torch.cat(pos_flat, dim=1)

        memory = self.encoder(src, pos, spatial_shapes)               # (B, sumHW, C)

        # ---- split memory back into per-level maps ----
        sizes = [h * w for h, w in spatial_shapes]
        parts = memory.split(sizes, dim=1)
        enc = [p.transpose(1, 2).reshape(b, self.hidden_dim, h, w)
               for p, (h, w) in zip(parts, spatial_shapes)]            # [enc8, enc16, enc32]

        # ---- FPN: lift enc8 (1/8) to 1/2 mask features using f4, f2 ----
        y = F.interpolate(enc[0], size=f4.shape[-2:], mode="bilinear", align_corners=False)
        y = self.mask_conv4(y + self.mask_lat4(f4))                    # 1/4
        y = F.interpolate(y, size=f2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.mask_conv2(y + self.mask_lat2(f2))                    # 1/2
        mask_features = self.mask_proj(y)                             # (B, C, H/2, W/2)

        # ---- transformer decoder feats: low-res first (M2F: 1/32, 1/16, 1/8) ----
        ms_feats = [enc[2], enc[1], enc[0]][: self.num_transformer_feats]
        return mask_features, ms_feats
