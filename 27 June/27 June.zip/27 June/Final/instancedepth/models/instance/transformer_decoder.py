"""Two-stream Mask2Former transformer decoder (InstanceDepth Fig. 7).

This is the standard Mask2Former decoder (M2F paper Sec. 3.2: masked cross-attn ->
self-attn -> FFN, learnable queries, no dropout, round-robin multi-scale features),
extended to carry the paper's task-specific query streams:

    * MASK stream  (N queries): predicts instance masks + classes and drives the
      masked cross-attention. This stream is pure Mask2Former.
    * DEPTH stream (N queries): reads instance content for the depth layer. Each
      depth query i is localized to mask query i's predicted region, and a block
      self-attention mask forbids the MASK stream from attending to the DEPTH
      stream. The mask/class predictions therefore depend ONLY on the mask
      queries -- the (previously unsupervised) depth queries can no longer corrupt
      mask quality or instance separation.

The two final query streams are returned for the query-fusion depth head.
"""

from __future__ import annotations

from typing import Callable, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class _FFN(nn.Module):
    def __init__(self, dim: int, hidden: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden), nn.ReLU(inplace=True),
            nn.Dropout(dropout), nn.Linear(hidden, dim))
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x + self.drop(self.net(x)))


class _DecoderLayer(nn.Module):
    def __init__(self, dim: int, num_heads: int, ffn_hidden: int, dropout: float) -> None:
        super().__init__()
        self.cross_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout)
        self.norm_ca = nn.LayerNorm(dim)
        self.self_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout)
        self.norm_sa = nn.LayerNorm(dim)
        self.ffn = _FFN(dim, ffn_hidden, dropout)
        self.drop = nn.Dropout(dropout)

    def forward(
        self,
        query: torch.Tensor,                    # (Nq,B,C)
        query_pos: torch.Tensor,                # (Nq,B,C)
        memory: torch.Tensor,                   # (HW,B,C)
        memory_pos: torch.Tensor,               # (HW,B,C)
        cross_attn_mask: Optional[torch.Tensor],   # (B*heads,Nq,HW) bool
        self_attn_mask: Optional[torch.Tensor] = None,  # (Nq,Nq) bool
    ) -> torch.Tensor:
        # masked cross-attention (M2F order: cross before self)
        q = query + query_pos
        k = memory + memory_pos
        ca, _ = self.cross_attn(q, k, value=memory, attn_mask=cross_attn_mask)
        query = self.norm_ca(query + self.drop(ca))
        # self-attention (block mask keeps the mask stream independent of depth)
        q2 = query + query_pos
        sa, _ = self.self_attn(q2, q2, value=query, attn_mask=self_attn_mask)
        query = self.norm_sa(query + self.drop(sa))
        return self.ffn(query)


class TransformerDecoder(nn.Module):
    """Mask2Former decoder with separate mask/depth query streams (Fig. 7)."""

    def __init__(
        self,
        hidden_dim: int = 256,
        num_heads: int = 8,
        num_layers: int = 9,
        ffn_hidden: int = 2048,
        dropout: float = 0.0,
        mask_threshold: float = 0.5,
    ) -> None:
        super().__init__()
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.mask_threshold = mask_threshold
        self.layers = nn.ModuleList(
            [_DecoderLayer(hidden_dim, num_heads, ffn_hidden, dropout) for _ in range(num_layers)])

    def _cross_attn_mask(self, mask_logits: torch.Tensor, feat_hw) -> torch.Tensor:
        """mask_logits (B,N,Hf,Wf) -> (B*heads,N,h*w) bool (True = block)."""
        h, w = feat_hw
        ml = F.interpolate(mask_logits, size=(h, w), mode="bilinear", align_corners=False)
        attn = (ml.sigmoid() < self.mask_threshold).flatten(2)      # (B,N,h*w)
        # a query that blocks EVERY location -> softmax(all -inf)=NaN; let it see all.
        attn[attn.all(dim=-1)] = False
        attn = attn.unsqueeze(1).repeat(1, self.num_heads, 1, 1).flatten(0, 1)
        return attn.detach()                                        # (B*heads,N,h*w)

    def forward(
        self,
        mask_query: torch.Tensor,                       # (N,B,C)
        depth_query: torch.Tensor,                      # (N,B,C)
        mask_pos: torch.Tensor,                         # (N,B,C)
        depth_pos: torch.Tensor,                        # (N,B,C)
        multi_scale_feats: List[torch.Tensor],          # each (B,C,h,w), low-res first
        multi_scale_pos: List[torch.Tensor],            # each (B,C,h,w)
        mask_features: torch.Tensor,                    # (B,C,Hf,Wf)
        predictor: Callable[[torch.Tensor, torch.Tensor], Tuple[torch.Tensor, torch.Tensor]],
    ) -> Tuple[List[Tuple[torch.Tensor, torch.Tensor]], torch.Tensor, torch.Tensor]:
        n = mask_query.shape[0]
        query = torch.cat([mask_query, depth_query], dim=0)         # (2N,B,C)
        query_pos = torch.cat([mask_pos, depth_pos], dim=0)
        num_feats = len(multi_scale_feats)

        # block self-attention mask: MASK queries cannot attend to DEPTH queries.
        sa_mask = torch.zeros(2 * n, 2 * n, dtype=torch.bool, device=query.device)
        sa_mask[:n, n:] = True

        # predictions come from the MASK stream only (first N queries).
        predictions: List[Tuple[torch.Tensor, torch.Tensor]] = []
        mask_logits, class_logits = predictor(query[:n], mask_features)   # prediction 0
        predictions.append((mask_logits, class_logits))

        for i, layer in enumerate(self.layers):
            feat, pos = multi_scale_feats[i % num_feats], multi_scale_pos[i % num_feats]
            h, w = feat.shape[-2:]
            memory = feat.flatten(2).permute(2, 0, 1)                   # (h*w,B,C)
            memory_pos = pos.flatten(2).permute(2, 0, 1)
            # depth query i shares mask query i's attention region (tile rows N->2N)
            ca_n = self._cross_attn_mask(mask_logits, (h, w))           # (B*heads,N,hw)
            ca_2n = torch.cat([ca_n, ca_n], dim=1)                      # (B*heads,2N,hw)
            query = layer(query, query_pos, memory, memory_pos, ca_2n, sa_mask)
            mask_logits, class_logits = predictor(query[:n], mask_features)
            predictions.append((mask_logits, class_logits))

        return predictions, query[:n], query[n:]                       # preds, mask_q, depth_q
