from __future__ import annotations

import torch
import torch.nn as nn

class QueryFusion(nn.Module):
    def __init__(self,hidden_dim: int) -> None:
        super().__init__()
        self.fuse=nn.Sequential(
            nn.Linear(hidden_dim*2,hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim,hidden_dim),
        )
        self.gate=nn.Sequential(
            nn.Linear(hidden_dim*2,hidden_dim),
            nn.Sigmoid()
        )
        self.norm=nn.LayerNorm(hidden_dim)

    def forward(self,mask_q: torch.Tensor, depth_q: torch.Tensor) -> torch.Tensor:
        cat=torch.cat([depth_q,mask_q],dim=-1)      # (N,B,2C)
        delta=self.fuse(cat)
        g=self.gate(cat)
        fused=depth_q+g*delta
        return self.norm(fused)                     # (N,B,C)