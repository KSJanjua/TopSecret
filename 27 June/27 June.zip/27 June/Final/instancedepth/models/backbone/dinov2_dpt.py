"""DINOv2 backbone with a DPT-style reassemble + RefineNet fusion neck.

Paper basis
-----------
Sec. 4.3 uses a pretrained DINOv2 backbone [37] for feature extraction; the
ablation baseline (Sec. 5.3) is a Depth-Anything-V2 encoder + DPT decoder, and
DA-V2 = DINOv2 encoder + DPT head [41, 53]. Fig. 5 then consumes "Backbone
Multiscale Features" at strides 1/8, 1/4, 1/2.

Why this is a real DPT neck (not bilinear upsampling)
-----------------------------------------------------
A ViT is single-scale: every token lives on one H/patch grid. To recover genuine
multi-scale features DPT [41] (and DA-V2 [53]) "reassemble" several transformer
layers and fuse them with RefineNet blocks built from residual conv units and
learned upsampling. The previous implementation only `interpolate`-d one token
grid to three sizes, so all three "scales" were the same blurred map -- a primary
cause of soft / incomplete instance masks. Here each output stride is produced
from a distinct fused pyramid level with learned convolutions.

Tensor flow (ViT-L/14, embed_dim=1024, input HxW divisible by 14)
    rgb                              (B, 3, H, W)
    tokens @ hook_layers (each)      (B, Np, 1024)         Np = (H/14)*(W/14)
    -> grid                          (B, 1024, H/14, W/14)
    -> project (1x1)                 (B, C, H/14, W/14)
    -> RefineNet fusion (deep->shallow, x2 upsample each) -> pyramid (coarse->fine)
    -> per-stride resize + 3x3 head  f8 (B,C,H/8,W/8), f4 (B,C,H/4,W/4), f2 (B,C,H/2,W/2)
Returned coarse -> fine: [f8, f4, f2].
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class BackboneConfig:
    """Configuration for the DINOv2 + DPT neck."""

    model_name: str = "vit_large_patch14_dinov2.lvd142m"
    out_channels: int = 256
    out_strides: Tuple[int, ...] = (8, 4, 2)        # coarse -> fine (Fig. 5)
    hook_layers: Tuple[int, ...] = (11, 17, 23)     # one ViT layer per output stride
    patch_size: int = 14
    pretrained: bool = True
    freeze: bool = False


class _ResidualConvUnit(nn.Module):
    """DPT residual conv unit: pre-activated 3x3 -> 3x3 with a skip connection."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.act = nn.GELU()
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv1(self.act(x))
        out = self.conv2(self.act(out))
        return out + x


class _FeatureFusionBlock(nn.Module):
    """DPT/RefineNet fusion: add the skip, refine, upsample x2, project."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.rcu_skip = _ResidualConvUnit(channels)
        self.rcu_out = _ResidualConvUnit(channels)
        self.out_conv = nn.Conv2d(channels, channels, kernel_size=1)

    def forward(self, x: torch.Tensor, skip: torch.Tensor = None) -> torch.Tensor:
        if skip is not None:
            if skip.shape[-2:] != x.shape[-2:]:        # bring the patch-grid skip up to x
                skip = F.interpolate(skip, size=x.shape[-2:], mode="bilinear",
                                     align_corners=False)
            x = x + self.rcu_skip(skip)
        x = self.rcu_out(x)
        x = F.interpolate(x, scale_factor=2.0, mode="bilinear", align_corners=False)
        return self.out_conv(x)


class DINOv2DPTBackbone(nn.Module):
    """DINOv2 encoder + DPT neck exposing 1/8, 1/4, 1/2 multi-scale features."""

    def __init__(self, cfg: BackboneConfig) -> None:
        super().__init__()
        self.cfg = cfg
        import timm  # local import keeps the dependency lazy

        overlay = None
        w = os.environ.get("DINOV2_WEIGHTS")           # local weights (offline cluster)
        if w:
            overlay = dict(file=w)

        self.vit = timm.create_model(
            cfg.model_name,
            pretrained=cfg.pretrained,
            num_classes=0,
            dynamic_img_size=True,
            pretrained_cfg_overlay=overlay,            # None -> normal behaviour
        )
        self.embed_dim: int = self.vit.embed_dim
        self.patch_size: int = cfg.patch_size
        c = cfg.out_channels

        assert len(cfg.hook_layers) == len(cfg.out_strides), (
            "hook_layers and out_strides must have equal length")
        self.num_scales = len(cfg.out_strides)

        # one 1x1 projection per hooked ViT layer (reassemble to the patch grid)
        self.projects = nn.ModuleList(
            [nn.Conv2d(self.embed_dim, c, kernel_size=1) for _ in range(self.num_scales)])
        # one RefineNet fusion block per stage
        self.fusions = nn.ModuleList(
            [_FeatureFusionBlock(c) for _ in range(self.num_scales)])
        # one output head per emitted stride
        self.out_heads = nn.ModuleList(
            [nn.Sequential(
                nn.Conv2d(c, c, kernel_size=3, padding=1),
                nn.GroupNorm(32, c),
                nn.GELU(),
            ) for _ in range(self.num_scales)])

        if cfg.freeze:
            self.freeze_backbone()

    # --------------------------------------------------------------- utils
    def freeze_backbone(self) -> None:
        for p in self.vit.parameters():
            p.requires_grad_(False)
        self.vit.eval()

    def unfreeze_backbone(self) -> None:
        for p in self.vit.parameters():
            p.requires_grad_(True)

    def _hook_indices(self) -> List[int]:
        return sorted(set(self.cfg.hook_layers))

    # --------------------------------------------------------------- forward
    def forward(self, rgb: torch.Tensor) -> List[torch.Tensor]:
        """Return [f8, f4, f2] (coarse -> fine). H, W must be divisible by patch_size."""
        b, _, h, w = rgb.shape
        assert h % self.patch_size == 0 and w % self.patch_size == 0, (
            f"Input H,W ({h},{w}) must be divisible by patch_size {self.patch_size}.")
        hg, wg = h // self.patch_size, w // self.patch_size

        tokens = self.vit.get_intermediate_layers(
            rgb, n=self._hook_indices(), reshape=False, norm=True)
        layer_map = dict(zip(self._hook_indices(), tokens))

        # reassemble each hooked layer to the patch grid, project to C
        feats: List[torch.Tensor] = []
        for hook, proj in zip(self.cfg.hook_layers, self.projects):
            grid = layer_map[hook].transpose(1, 2).reshape(b, self.embed_dim, hg, wg)
            feats.append(proj(grid))                   # (B, C, hg, wg)

        # RefineNet top-down fusion (deepest -> shallowest); each block upsamples x2.
        # pyramid is ordered coarse -> fine (same order as out_strides 8,4,2).
        path = self.fusions[-1](feats[-1])
        pyramid: List[torch.Tensor] = [path]
        for i in range(self.num_scales - 2, -1, -1):
            path = self.fusions[i](path, feats[i])
            pyramid.append(path)

        # map each fused level to its exact output stride and refine
        outputs: List[torch.Tensor] = []
        for k, stride in enumerate(self.cfg.out_strides):
            x = F.interpolate(pyramid[k], size=(h // stride, w // stride),
                              mode="bilinear", align_corners=False)
            outputs.append(self.out_heads[k](x))       # (B, C, H/stride, W/stride)
        return outputs
