"""
Prediction heads for Holistic Depth Initialization.

    RangeSegHead  -> S: per pixel distribution over rd depth ranges (softmax)
    InitDepthHead -> D: initial dense metric depth (1 channel)
    ConfidenceNet -> C: Phi_d in Eq.1, per pixel per-range confidence (sigmoid)

Paper Specified:
S="depth range segmentation",
D="depth estimation", 
both from a "lightweight convolution network";
C_i=sigmoid(Phi_d(F_i,D_i)) (eq. 1), a "small network".

Strongly Inferred:
S is a distribution over rd ranges -> softmax over the range channel,
making R_i=sum_rd(C_i * S_i) (Eq. 2) a confidence-weighted expectation centered near 1.

Reasonable Assumption:
Phi_d takes concat(F_i,D_i) and is a 2-layer 1x1 conv stack ending in sigmoid, emitting rd confidence maps.

Tensor shapes (C=feature channels, rd=number of depth ranges)
    F (B,C,h,w)
    S (B,rd,h,w)    softmax over dim=1
    D (B,1,h,w)     in [0, MAX_d]
    C (B,rd,h,w)    sigmoid, in [0,1]
"""

from __future__ import annotations

import torch 
import torch.nn as nn
import torch.nn.functional as F

class RangeSegHead(nn.Module):
    def __init__(self,in_channels: int, num_ranges: int, hidden: int=128) -> None:
        super().__init__()
        self.num_ranges=num_ranges
        self.net=nn.Sequential(
            nn.Conv2d(in_channels,hidden,kernel_size=3,padding=1),
            nn.GroupNorm(32,hidden),
            nn.GELU(),
            nn.Conv2d(hidden,num_ranges,kernel_size=1),
        )
    
    def forward(self, x:torch.Tensor):
        logits=self.net(x)                  # (B,rd,h,w)
        probs=F.softmax(logits,dim=1)
        return logits,probs

class InitDepthHead(nn.Module):
    def __init__(self, in_channels: int, max_depth: float, hidden: int=128) -> None:
        super().__init__()
        self.max_depth=max_depth
        self.net=nn.Sequential(
            nn.Conv2d(in_channels, hidden, kernel_size=3, padding=1),
            nn.GroupNorm(32,hidden),
            nn.GELU(),
            nn.Conv2d(hidden,1,kernel_size=1),
        )
    
    def forward(self,x:torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.net(x))*self.max_depth # (B,1,h,w)
    
class ConfidenceNet(nn.Module):
    """Phi_d: C_i = Sigmoid(Phi_d(F_i,D_i)) (Eq.1)"""

    def __init__(self,in_channels: int, num_ranges: int, hidden: int=128) -> None:
        super().__init__()
        self.net=nn.Sequential(
            nn.Conv2d(in_channels+1,hidden,kernel_size=1),
            nn.GELU(),
            nn.Conv2d(hidden,num_ranges,kernel_size=1),
        )

    def forward(self,feats: torch.Tensor, depth:torch.Tensor) -> torch.Tensor:
        x=torch.cat([feats,depth],dim=1)    # (B,C+1,h,w)
        return torch.sigmoid(self.net(x))   # (B,rd,h,w)