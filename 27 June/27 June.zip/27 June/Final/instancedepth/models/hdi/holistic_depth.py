"""Holistic Depth Initialization config (paper Sec. 4.1).

The HDI stage itself (backbone -> depth-range decoder -> S/D/C heads -> iterative
refinement, Eqs. 1-4) is implemented inline in models/instance_depth.py so the
backbone is shared across all three stages. This module only owns HDIConfig, the
typed configuration consumed by RunConfig.

Refinement equations (implemented in InstanceDepth._hdi_from_feats):
    C_i = Sigmoid(Phi_d(F_i, D_i))                              (Eq. 1)
    R_i = sum_{rd} (C_i * S_i)                                  (Eq. 2)
    E_i = (2 * R_i - 1) * (MAX_d / rd)        # signed form of (Eq. 3)
    D_{i+1} = D_i + E_i                                         (Eq. 4)

MAX_d is divided into rd depth ranges; rd = round(max_depth / partition_meters).
Table 5 reports 2 m partitioning (rd = 5) as the best setting.

Note on Eq. 3: the literal print, E = 2*(R-1)*step with R in [0,1], is always
<= 0, so it can only DECREASE depth -- a degenerate, one-sided correction. We use
the signed form E = (2R-1)*step, which matches the signed-correction pattern the
paper uses for the instance refinement (Eq. 9) and lets depth move both ways.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..backbone.dinov2_dpt import BackboneConfig
from .range_decoder import RangeDecoderConfig


@dataclass
class HDIConfig:
    backbone: BackboneConfig = field(default_factory=BackboneConfig)
    decoder: RangeDecoderConfig = field(default_factory=RangeDecoderConfig)
    max_depth: float = 10.0          # MAX_d, metres (paper Fig. 2)
    partition_meters: float = 2.0    # Table 5 best -> rd = max_depth / partition
    num_refine_steps: int = 3
    head_hidden: int = 128

    @property
    def num_ranges(self) -> int:
        return max(int(round(self.max_depth / self.partition_meters)), 1)
