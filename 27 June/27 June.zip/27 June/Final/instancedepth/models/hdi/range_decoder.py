"""
Depth Range Feature Decoder (Figure 5).

Takes backbone multi-scale features [f8,f4,f2] (coarse->fine), applies a 
PatchAttentionBlock at each scale with the patch sizes from Fig. 5 (4,8,16),
and fuses them coarse-to-fine into a single "Depth Range Features" map.

Paper Specified:
Fig. 5: three scales, patch sizes 4/8/16, patch-conv -> FC -> patch attention, 
coarse-to-dine fusion (the (+) symbols) producing "Depth Range Features".

Reasonable Assumption:
Fusion = upsample running coarse feature to the next scale, add to that scale's patch-attended feature,
smooth with 3x3 conv. Final map emitted at the finest decoder stride.

Tensor flow (C=channels)
    f8 (B,C,H/8,W/8)    - PatchAttn(P=4) -> a8
    f4 (B,C,H/4,W/4)    - PatchAttn(P=8) -> a4
    f2 (B,C,H/2,W/2)    - PatchAttn(P=16) -> a2
    a8 -up-> + a4 -> g4 : g4 -up-> + a2 -> g2
    Depth Range Features=g2(B,C,H/2,W/2)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List,Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .patch_attention import PatchAttentionBlock

@dataclass
class RangeDecoderConfig:
    channels: int=256
    patch_sizes: Tuple[int,...]=(4,8,16) # coarse -> fine (Fig. 5)
    num_heads: int=8
    mlp_ratio: float=4.0

class DepthRangeFeatureDecoder(nn.Module):
    """Coarse-to-fine fusion producing depth-range features."""

    def __init__(self,cfg:RangeDecoderConfig, num_scales: int=3) -> None:
        super().__init__()
        self.cfg=cfg
        assert len(cfg.patch_sizes)==num_scales, "patch_sizes length must match scales"

        self.patch_blocks=nn.ModuleList(
            [
                PatchAttentionBlock(cfg.channels,p,cfg.num_heads,cfg.mlp_ratio) for p in cfg.patch_sizes
            ]
        )
        self.fuse_convs=nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(cfg.channels,cfg.channels,kernel_size=3,padding=1),
                    nn.GroupNorm(32,cfg.channels),
                    nn.GELU(),
                )
                for _ in range(num_scales-1)
            ]
        )

    def forward(self,feats: List[torch.Tensor]) -> torch.Tensor:
        assert len(feats)==len(self.patch_blocks), "feature/scale count mismatch"
        attended=[blk(f) for blk,f in zip(self.patch_blocks,feats)]
        running=attended[0]
        for i in range(1,len(attended)):
            target_hw=attended[i].shape[-2:]
            running=F.interpolate(running,size=target_hw,mode="bilinear",align_corners=False)
            running=running+attended[i]
            running=self.fuse_convs[i-1](running)
        return running
