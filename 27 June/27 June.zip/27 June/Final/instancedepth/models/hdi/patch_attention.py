"""
Patch Attention Block (Figure 5)

Per scale the decoder applies: patch-wise convolution -> FC layer -> Patch Attention.
Figure 5 lists patch sizes 4x4, 8x8, 16x16 for the 1/8, 1/4, 1/2 scales respectively.

Paper Specified:
Pipeline order (patch conv -> FC -> patch attention) and the three patch sizes(4x4,8x8,16x16) are stated.

Reasonable Assumption:
The internal mechanics of "patch attention" are not defined. We implement it as multi-head self-attention
over the tokens produced by non-overlapping pitch embedding -- each PxP patch becomes one token, 
tokens attend to each other, then are projected back to a spatial map. Heads/FFN ratio configurable.

Tensor flow (single scale, feature map F of shape (B,C,H,W), patch P)
    F                           (B,C,H,W)
    patch conv (Stride P)       (B,C,H/P,W/P)
    flatten                     (B, (H/P)*(W/P),C)
    FC layer                    (B,N_tok,C)
    MHSA + FFN                  (B,N_tok,C)
    reshape to grid             (B,C,H/P,W/P)
    upsample back to (H,W)      (B,C,H,W)
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

class _MHSA(nn.Module):
    """Multi-head self-attention over a (B,N,C) token sequence."""

    def __init__(self,dim: int, num_heads: int, attn_drop: float, proj_drop:float) -> None:
        super().__init__()
        assert dim%num_heads==0, "dim must be divisible by num_heads"
        self.num_heads=num_heads
        self.head_dim=dim//num_heads
        self.scale=self.head_dim**-0.5
        self.qkv=nn.Linear(dim,dim*3)
        self.attn_drop=nn.Dropout(attn_drop)
        self.proj=nn.Linear(dim,dim)
        self.proj_drop=nn.Dropout(proj_drop)
    
    def forward(self,x:torch.Tensor) -> torch.Tensor:
        b,n,c=x.shape
        qkv=self.qkv(x).reshape(b,n,3,self.num_heads,self.head_dim).permute(2,0,3,1,4)
        q,k,v=qkv[0],qkv[1],qkv[2]                  # each (B,heads,N,head_dim)
        attn=(q@k.transpose(-2,-1))*self.scale      # (B,heads,N,N)
        attn=attn.softmax(dim=-1)
        attn=self.attn_drop(attn)
        out=(attn@v).transpose(1,2).reshape(b,n,c)
        out=self.proj_drop(self.proj(out))
        return out

class PatchAttentionBlock(nn.Module):
    """Patch conv -> FC -> patch attention for one decoder scale."""

    def __init__(
            self,
            channels: int, 
            patch_size: int,
            num_heads: int=8,
            mlp_ratio: float=4.0,
            attn_drop: float=0.0,
            proj_drop: float=0.0,
    )->None:
        super().__init__()
        self.patch_size=patch_size
        self.channels=channels

        self.patch_conv=nn.Conv2d(channels,channels,kernel_size=patch_size,stride=patch_size)
        self.fc=nn.Linear(channels,channels)

        self.norm1=nn.LayerNorm(channels)
        self.attn=_MHSA(channels,num_heads,attn_drop,proj_drop)
        self.norm2=nn.LayerNorm(channels)
        hidden=int(channels*mlp_ratio)
        self.ffn=nn.Sequential(nn.Linear(channels,hidden),nn.GELU(),nn.Linear(hidden,channels))

    def forward(self,x:torch.Tensor)->torch.Tensor:
        """x:(B,C,H,W) -> (B,C,H,W)"""
        b,c,h,w=x.shape
        tok=self.patch_conv(x)                  #(B,C,H/P,W/P)
        hp,wp=tok.shape[-2:]
        tok=tok.flatten(2).transpose(1,2)       #(B,N,C)
        tok=self.fc(tok)
        tok=tok+self.attn(self.norm1(tok))
        tok=tok+self.ffn(self.norm2(tok))
        grid=tok.transpose(1,2).reshape(b,c,hp,wp)
        out=F.interpolate(grid,size=(h,w),mode="bilinear",align_corners=False)
        return out