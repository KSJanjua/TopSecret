"""Model factory for the integrated InstanceDepth model.

The whole framework (HDI + instance head + refinement) is one nn.Module built
from a single RunConfig, so only two entry points are needed:

    build_instance_depth(cfg_dict)        # from a parsed YAML dict
    build_instance_depth_from_yaml(path)  # from a YAML file
    build_from_registry(name, cfg_dict)   # by registered model name

These are what train.py / evaluate.py / infer_video.py use.
"""

from __future__ import annotations

from typing import Any, Dict


def build_instance_depth(cfg_dict: Dict[str, Any]):
    """Build the full integrated InstanceDepth model from a nested dict."""
    from .configs.run_config import RunConfig
    from .models.instance_depth import InstanceDepth

    cfg = RunConfig.from_dict(cfg_dict)
    return InstanceDepth(cfg)


def build_instance_depth_from_yaml(path: str):
    """Build the full integrated InstanceDepth model from a YAML config."""
    import yaml

    with open(path, "r") as f:
        return build_instance_depth(yaml.safe_load(f))


def build_from_registry(name: str, cfg_dict: Dict[str, Any]):
    """Build any registered model variant by name."""
    from .configs.run_config import RunConfig
    from .models import instance_depth  # noqa: F401  ensures @register_model runs
    from .models.registry import MODEL_REGISTRY

    cfg = RunConfig.from_dict(cfg_dict)
    return MODEL_REGISTRY.get(name)(cfg)
