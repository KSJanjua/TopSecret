"""Dense depth metrics for evaluation (paper Sec. 5.1, Tables 2-3).

depth_metrics computes, on valid ground-truth pixels, the standard monocular
depth measures used by InstanceDepth:

    RMS     sqrt(mean( (d - d*)^2 ))
    REL     mean( |d - d*| / d* )
    RMSlog  sqrt(mean( (ln d - ln d*)^2 ))
    Log10   mean( |log10 d - log10 d*| )
    sigma_i fraction of pixels with max(d/d*, d*/d) < 1.25^i,  i = 1, 2, 3

The returned dict keys (RMS, REL, RMSlog, Log10, sigma1..3) match the schema the
trainer/evaluator already write to eval_*.json. Returns ``None`` when a frame has
no valid pixels so the caller can skip it without polluting the running average.
"""

from __future__ import annotations

from typing import Dict, Optional

import torch

_LN10 = 2.302585092994046


@torch.no_grad()
def depth_metrics(
    pred: torch.Tensor,
    gt: torch.Tensor,
    max_d: float = 10.0,
    min_d: float = 1e-3,
    region: Optional[torch.Tensor] = None,
) -> Optional[Dict[str, float]]:
    """Per-frame depth metrics on valid GT pixels.

    Parameters
    ----------
    pred, gt : tensors broadcastable to the same shape, e.g. (1, H, W) or (H, W),
               metric depth in metres. ``gt <= 0`` marks invalid sensor pixels.
    max_d    : metric clamp; GT outside (min_d, max_d] is ignored.
    region   : optional bool mask (same H, W) restricting evaluation (e.g. to
               person pixels for the object-only protocol).
    """
    pred = pred.detach().float().reshape(-1)
    gt = gt.detach().float().reshape(-1)

    valid = torch.isfinite(gt) & (gt > min_d) & (gt <= max_d) & torch.isfinite(pred)
    if region is not None:
        valid = valid & region.reshape(-1).bool()
    if valid.sum() == 0:
        return None

    p = pred[valid].clamp(min=min_d, max=max_d)
    g = gt[valid].clamp(min=min_d, max=max_d)

    diff = p - g
    rms = torch.sqrt((diff ** 2).mean())
    rel = (diff.abs() / g).mean()

    log_diff = torch.log(p) - torch.log(g)
    rms_log = torch.sqrt((log_diff ** 2).mean())
    log10 = (log_diff.abs() / _LN10).mean()          # |log10 p - log10 g|

    ratio = torch.maximum(p / g, g / p)
    s1 = (ratio < 1.25).float().mean()
    s2 = (ratio < 1.25 ** 2).float().mean()
    s3 = (ratio < 1.25 ** 3).float().mean()

    return {
        "RMS": float(rms),
        "REL": float(rel),
        "RMSlog": float(rms_log),
        "Log10": float(log10),
        "sigma1": float(s1),
        "sigma2": float(s2),
        "sigma3": float(s3),
    }
