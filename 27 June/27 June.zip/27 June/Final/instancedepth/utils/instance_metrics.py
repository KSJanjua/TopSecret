"""Instance-mask training monitor (used for Phase-2 logging in train.py).

mean_matched_iou reports how well the predicted instance masks cover the ground
truth in one image: it optimally matches predictions to GT instances by mask IoU
(Hungarian assignment) and averages the matched IoU over the GT instances, so
missing a GT instance counts as 0. This is a lightweight diagnostic for the
"masks complete / instances separated?" question during training; it is NOT one
of the paper's reported metrics.
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment


def _iou_matrix(pred: np.ndarray, gt: np.ndarray) -> np.ndarray:
    """pred (M, H, W) bool, gt (G, H, W) bool -> (M, G) IoU."""
    p = pred.reshape(pred.shape[0], -1).astype(np.float32)      # (M, HW)
    g = gt.reshape(gt.shape[0], -1).astype(np.float32)          # (G, HW)
    inter = p @ g.T                                             # (M, G)
    area_p = p.sum(1)[:, None]
    area_g = g.sum(1)[None, :]
    union = area_p + area_g - inter
    return inter / np.clip(union, 1e-6, None)


def mean_matched_iou(pred: np.ndarray, gt: np.ndarray) -> float:
    """Mean over GT instances of the Hungarian-matched mask IoU.

    pred : (M, H, W) bool predicted instance masks (M may be 0).
    gt   : (G, H, W) bool ground-truth instance masks.
    Returns 0.0 when there are no GT instances or no predictions.
    """
    g = gt.shape[0]
    if g == 0 or pred.shape[0] == 0:
        return 0.0
    iou = _iou_matrix(pred, gt)                                 # (M, G)
    rows, cols = linear_sum_assignment(-iou)                    # maximize IoU
    matched = iou[rows, cols].sum()
    return float(matched / g)                                  # unmatched GT -> 0
