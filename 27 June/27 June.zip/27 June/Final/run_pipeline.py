#!/usr/bin/env python
"""Run the complete InstanceDepth training pipeline end to end (paper Sec. 4.3).

Phase 1  Holistic Depth Initialization      55k iters, lr 1e-5   (backbone trainable)
Phase 2  Instance Depth Layer Specialization 25k iters, lr 1e-5   (backbone frozen)
Phase 3  Occlusion-Aware Joint Refinement    25k iters, lr 1e-6   (instance head frozen)

Each phase's `ckpt_final.pth` is fed to the next via --init-from, then phase 3 is
evaluated on the test split. Iteration counts and learning rates come from
train.py's paper defaults; this wrapper only sets memory/throughput flags and
wires the checkpoints together. It is fail-fast: a phase error or a missing
checkpoint stops the run.

Memory (tuned for ~40 GB VRAM, correctness-preserving):
  * bf16 autocast (--amp) — no grad scaler, log-based depth losses stay in fp32.
  * per-phase batch size — phase 2 freezes the backbone, so it fits a larger batch.
None of these change the model or deviate from the paper.

Examples
--------
    # full run (DINOv2 downloads on first use; or set DINOV2_WEIGHTS for offline)
    python run_pipeline.py --data-root gid_custom --out runs

    # resume from phase 2 (phase 1 already done), fp32, custom batch
    python run_pipeline.py --data-root gid_custom --out runs --start-phase 2 --no-amp --batch-size 4
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TRAIN = HERE / "train.py"
EVAL = HERE / "evaluate.py"
DEFAULT_CONFIG = HERE / "instancedepth" / "configs" / "instance_depth.yaml"

# ~40 GB-friendly per-phase batch with bf16. Phase 2 freezes the ViT-L backbone
# (no backbone activations retained for backward) so it fits a larger batch.
DEFAULT_BATCH = {1: 4, 2: 8, 3: 4}


def run(cmd: list) -> None:
    print("\n$ " + " ".join(str(c) for c in cmd), flush=True)
    subprocess.run(cmd, check=True)        # raises CalledProcessError -> stops the pipeline


def main() -> None:
    ap = argparse.ArgumentParser(description="InstanceDepth full 3-phase pipeline")
    ap.add_argument("--data-root", required=True, help="data engine out_root (e.g. gid_custom)")
    ap.add_argument("--out", default="runs", help="output dir; phase k -> <out>/phase{k}")
    ap.add_argument("--model-config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--image-size", type=int, nargs=2, default=(504, 896),
                    help="H W, both divisible by 14 (training resolution)")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--num-workers", type=int, default=8)
    ap.add_argument("--batch-size", type=int, default=None,
                    help="override the per-phase default (%s) for ALL phases" % DEFAULT_BATCH)
    ap.add_argument("--no-amp", action="store_true", help="disable bf16 autocast (run fp32)")
    ap.add_argument("--start-phase", type=int, choices=(1, 2, 3), default=1,
                    help="resume from this phase (requires the previous checkpoint)")
    ap.add_argument("--iters", type=int, default=None,
                    help="override iters for ALL phases (default: paper 55k/25k/25k)")
    ap.add_argument("--skip-eval", action="store_true", help="do not run evaluate.py at the end")
    args = ap.parse_args()

    out = Path(args.out)
    ckpt = {p: out / f"phase{p}" / "ckpt_final.pth" for p in (1, 2, 3)}
    use_amp = (not args.no_amp) and args.device.startswith("cuda")

    for phase in (1, 2, 3):
        if phase < args.start_phase:
            continue
        bs = args.batch_size or DEFAULT_BATCH[phase]
        cmd = [sys.executable, str(TRAIN),
               "--model-config", args.model_config,
               "--data-root", args.data_root,
               "--phase", str(phase),
               "--image-size", str(args.image_size[0]), str(args.image_size[1]),
               "--batch-size", str(bs),
               "--num-workers", str(args.num_workers),
               "--device", args.device,
               "--out", str(out / f"phase{phase}")]
        if use_amp:
            cmd.append("--amp")
        if args.iters is not None:
            cmd += ["--iters", str(args.iters)]
        if phase >= 2:                                  # chain the previous phase's weights
            prev = ckpt[phase - 1]
            if not prev.exists():
                sys.exit(f"[pipeline] missing {prev}; run phase {phase - 1} first "
                         f"(or set --start-phase {phase - 1}).")
            cmd += ["--init-from", str(prev)]
        print(f"\n========== PHASE {phase} (batch {bs}, amp={use_amp}) ==========")
        run(cmd)
        if not ckpt[phase].exists():
            sys.exit(f"[pipeline] phase {phase} finished but {ckpt[phase]} is missing.")
        print(f"[pipeline] phase {phase} complete -> {ckpt[phase]}")

    if not args.skip_eval:
        print("\n========== EVALUATE (phase 3, test split) ==========")
        run([sys.executable, str(EVAL),
             "--model-config", args.model_config,
             "--data-root", args.data_root,
             "--checkpoint", str(ckpt[3]),
             "--split", "test",
             "--image-size", str(args.image_size[0]), str(args.image_size[1]),
             "--device", args.device,
             "--out-json", str(out / "eval_phase3.json")])

    print("\n[pipeline] complete. Checkpoints:")
    for p in (1, 2, 3):
        print(f"  phase {p}: {ckpt[p]}")


if __name__ == "__main__":
    main()
