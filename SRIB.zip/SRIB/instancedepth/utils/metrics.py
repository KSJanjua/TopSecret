"""Shared depth metrics (paper Sec. 5.1 / Table 2).

Single source of truth so that the training-time TensorBoard curves
(`tb_progress.py`) and the final evaluation report (`evaluate.py`) are computed
identically and are therefore directly comparable. Both modules import this.

Metrics (over valid GT pixels, i.e. min_d < gt <= max_d, optionally restricted
to a region mask):
    RMS     sqrt(mean((d - d*)^2))
    REL     mean(|d - d*| / d*)
    RMSlog  sqrt(mean((log d - log d*)^2))
    Log10   mean(|log10 d - log10 d*|)
    sigma_i fraction with max(d/d*, d*/d) < 1.25^i, i = 1,2,3
"""

from __future__ import annotations

from typing import Dict, Optional

import torch


@torch.no_grad()
def depth_metrics(
    pred: torch.Tensor,
    gt: torch.Tensor,
    max_d: float = 10.0,
    min_d: float = 0.01,
    region: Optional[torch.Tensor] = None,
) -> Optional[Dict[str, float]]:
    """pred, gt: (1, H, W) metric depth for ONE frame.

    region: optional (1, H, W) / (H, W) bool or 0-1 mask; when given, metrics are
    computed only on pixels inside it (e.g. person masks). Returns the metric dict,
    or None if there are no valid pixels.
    """
    valid = (gt > min_d) & (gt <= max_d)
    if region is not None:
        valid = valid & region.reshape(valid.shape).bool()
    if valid.sum() == 0:
        return None
    p = pred[valid].clamp(min=min_d)
    g = gt[valid]
    thr = torch.maximum(p / g, g / p)
    return dict(
        RMS=float(torch.sqrt(((p - g) ** 2).mean())),
        REL=float(((p - g).abs() / g).mean()),
        RMSlog=float(torch.sqrt(((p.log() - g.log()) ** 2).mean())),
        Log10=float((p.log10() - g.log10()).abs().mean()),
        sigma1=float((thr < 1.25).float().mean()),
        sigma2=float((thr < 1.25 ** 2).float().mean()),
        sigma3=float((thr < 1.25 ** 3).float().mean()),
    )
