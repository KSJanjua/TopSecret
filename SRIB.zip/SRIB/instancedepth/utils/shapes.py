"""Lightweight attention based tensor helpers"""

from __future__ import annotations
from typing import Sequence

import torch

def assert_shape(t:torch.Tensor, expected:Sequence, name: str="tensor") -> None:
    """Assert a tensor matches 'expected: use None for wildcard dims.
    
    Example: assert_shape(x,(None,256,None,None),"range_feats")
    """
    actual=tuple(t.shape)
    if len(actual)!=len(expected):
        raise AssertionError(f"{name} rank {len(actual)} != expected {len(expected)} ({actual})")
    for i,(a,e) in enumerate(zip(actual,expected)):
        if e is not None and a!=e:
            raise AssertionError(f"{name}: dim {i} = {a}, expected {e} (full shape {actual})")