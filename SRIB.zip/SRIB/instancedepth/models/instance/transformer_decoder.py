
# from __future__ import annotations

# from typing import List, Optional

# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# class _FFN(nn.Module):
#     def __init__(self,dim: int, hidden: int, dropout: float) -> None:
#         super().__init__()
#         self.net=nn.Sequential(
#             nn.Linear(dim,hidden),
#             nn.ReLU(inplace=True),
#             nn.Dropout(dropout),
#             nn.Linear(hidden,dim)
#         )
#         self.norm=nn.LayerNorm(dim)
#         self.drop=nn.Dropout(dropout)

#     def forward(self,x:torch.Tensor) -> torch.Tensor:
#         return self.norm(x+self.drop(self.net(x)))
    
# class _DecoderLayer(nn.Module):
#     def __init__(self,dim: int, num_heads: int, ffn_hidden: int, dropout: float) -> None:
#         super().__init__()
#         self.cross_attn=nn.MultiheadAttention(dim,num_heads,dropout=dropout)
#         self.norm_ca=nn.LayerNorm(dim)
#         self.self_attn=nn.MultiheadAttention(dim,num_heads,dropout=dropout)
#         self.norm_sa=nn.LayerNorm(dim)
#         self.ffn=_FFN(dim,ffn_hidden,dropout)
#         self.drop=nn.Dropout(dropout)

#     def forward(
#             self,
#             query: torch.Tensor,                    # (N,B,C)
#             query_pos: torch.Tensor,                # (N,B,C)
#             memory: torch.Tensor,                   # (HW,B,C)
#             memory_pos: torch.Tensor,               # (HW,B,C)
#             attn_mask: Optional[torch.Tensor],      # (B*heads,N,HW) or None
#     ) -> torch.Tensor:
#         #Masked cross-attention
#         q=query+query_pos
#         k=memory+memory_pos
#         ca,_=self.cross_attn(q,k,value=memory,attn_mask=attn_mask)
#         query=self.norm_ca(query+self.drop(ca))
#         #Self-attention
#         q2=query+query_pos
#         sa,_=self.self_attn(q2,q2,value=query)
#         query=self.norm_sa(query+self.drop(sa))
#         #FFN
#         query=self.ffn(query)
#         return query
    
# class TransformerDecoder(nn.Module):
#     """Mask2Former tranformer decoder producing refined query features"""

#     def __init__(
#             self,
#             hidden_dim: int=256,
#             num_heads: int=8,
#             num_layers: int=9,
#             ffn_hidden: int=2048,
#             dropout: float=0.0,
#             mask_threshold: float=0.5
#     ) -> None: 
#         super().__init__()
#         self.num_layers=num_layers
#         self.num_heads=num_heads
#         self.mask_threshold=mask_threshold
#         self.layers=nn.ModuleList(
#             [_DecoderLayer(hidden_dim,num_heads,ffn_hidden,dropout) for _ in range(num_layers)]
#         )
#         self.decoder_norm=nn.LayerNorm(hidden_dim)

#     def _attn_mask(self, query: torch.Tensor, mask_features: torch.Tensor, feat_hw) -> torch.Tensor:
#         b = mask_features.shape[0]
#         n = query.shape[0]
#         q = query.permute(1, 0, 2)                              # (B, N, C)
#         mask_logits = torch.einsum("bnc,bchw->bnhw", q, mask_features)
#         h, w = feat_hw
#         ml = F.interpolate(mask_logits, size=(h, w), mode="bilinear", align_corners=False)
#         attn = (ml.sigmoid() < self.mask_threshold).flatten(2)  # (B, N, h*w) True = block
#         # A query that blocks EVERY location -> softmax(all -inf) = NaN.
#         # Reset any fully-blocked row to "attend everywhere".
#         attn[attn.all(dim=-1)] = False
#         attn = attn.unsqueeze(1).repeat(1, self.num_heads, 1, 1).flatten(0, 1)
#         return attn.detach()
    
#     def forward(
#             self,
#             query_feat: torch.Tensor,                   # (N,B,C)
#             query_pos: torch.Tensor,                    # (N,B,C)
#             multi_scale_feats: List[torch.Tensor],      # each (B,C,h,w), coarse->fine
#             multi_scale_pos: List[torch.Tensor],        # each (B,C,h,w)
#             mask_features: torch.Tensor                 # (B,C,hf,wf)
#     ) -> torch.Tensor:
#         query=query_feat
#         num_feats=len(multi_scale_feats)
#         for i, layer in enumerate(self.layers):
#             idx=i%num_feats
#             feat=multi_scale_feats[idx]
#             pos=multi_scale_pos[idx]
#             b,c,h,w=feat.shape
#             memory=feat.flatten(2).permute(2,0,1)                   # (h*w,B,C)
#             memory_pos=pos.flatten(2).permute(2,0,1)
#             attn_mask=self._attn_mask(query,mask_features,(h,w))
#             query=layer(query,query_pos,memory,memory_pos,attn_mask)
#         return self.decoder_norm(query)                             # (N,B,C)

from __future__ import annotations

from typing import Callable, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class _FFN(nn.Module):
    def __init__(self, dim: int, hidden: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden), nn.ReLU(inplace=True),
            nn.Dropout(dropout), nn.Linear(hidden, dim),
        )
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x + self.drop(self.net(x)))


class _DecoderLayer(nn.Module):
    def __init__(self, dim: int, num_heads: int, ffn_hidden: int, dropout: float) -> None:
        super().__init__()
        self.cross_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout)
        self.norm_ca = nn.LayerNorm(dim)
        self.self_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout)
        self.norm_sa = nn.LayerNorm(dim)
        self.ffn = _FFN(dim, ffn_hidden, dropout)
        self.drop = nn.Dropout(dropout)

    def forward(
        self,
        query: torch.Tensor,                    # (Nq,B,C)
        query_pos: torch.Tensor,                # (Nq,B,C)
        memory: torch.Tensor,                   # (HW,B,C)
        memory_pos: torch.Tensor,               # (HW,B,C)
        attn_mask: Optional[torch.Tensor],      # (B*heads,Nq,HW) or None
    ) -> torch.Tensor:
        # masked cross-attention
        q = query + query_pos
        k = memory + memory_pos
        ca, _ = self.cross_attn(q, k, value=memory, attn_mask=attn_mask)
        query = self.norm_ca(query + self.drop(ca))
        # self-attention
        q2 = query + query_pos
        sa, _ = self.self_attn(q2, q2, value=query)
        query = self.norm_sa(query + self.drop(sa))
        # FFN
        return self.ffn(query)


class TransformerDecoder(nn.Module):
    """Mask2Former decoder; returns per-layer predictions + final query features."""

    def __init__(
        self,
        hidden_dim: int = 256,
        num_heads: int = 8,
        num_layers: int = 9,
        ffn_hidden: int = 2048,
        dropout: float = 0.0,
        mask_threshold: float = 0.5,
    ) -> None:
        super().__init__()
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.mask_threshold = mask_threshold
        self.layers = nn.ModuleList(
            [_DecoderLayer(hidden_dim, num_heads, ffn_hidden, dropout) for _ in range(num_layers)]
        )

    def _attn_mask_from_logits(self, mask_logits: torch.Tensor, feat_hw) -> torch.Tensor:
        """mask_logits (B,Nq,Hf,Wf) -> (B*heads,Nq,h*w) bool (True = block)."""
        h, w = feat_hw
        ml = F.interpolate(mask_logits, size=(h, w), mode="bilinear", align_corners=False)
        attn = (ml.sigmoid() < self.mask_threshold).flatten(2)      # (B,Nq,h*w)
        # A query blocking EVERY location -> softmax(all -inf) = NaN; let it see all.
        attn[attn.all(dim=-1)] = False
        attn = attn.unsqueeze(1).repeat(1, self.num_heads, 1, 1).flatten(0, 1)
        return attn.detach()

    def forward(
        self,
        query_feat: torch.Tensor,                       # (Nq,B,C)
        query_pos: torch.Tensor,                        # (Nq,B,C)
        multi_scale_feats: List[torch.Tensor],          # each (B,C,h,w), coarse->fine
        multi_scale_pos: List[torch.Tensor],            # each (B,C,h,w)
        mask_features: torch.Tensor,                    # (B,C,Hf,Wf)
        predictor: Callable[[torch.Tensor, torch.Tensor], Tuple[torch.Tensor, torch.Tensor]],
    ) -> Tuple[List[Tuple[torch.Tensor, torch.Tensor]], torch.Tensor]:
        query = query_feat
        num_feats = len(multi_scale_feats)

        predictions: List[Tuple[torch.Tensor, torch.Tensor]] = []
        mask_logits, class_logits = predictor(query, mask_features)     # prediction 0 (initial)
        predictions.append((mask_logits, class_logits))

        for i, layer in enumerate(self.layers):
            idx = i % num_feats
            feat, pos = multi_scale_feats[idx], multi_scale_pos[idx]
            h, w = feat.shape[-2:]
            memory = feat.flatten(2).permute(2, 0, 1)                   # (h*w,B,C)
            memory_pos = pos.flatten(2).permute(2, 0, 1)
            attn_mask = self._attn_mask_from_logits(mask_logits, (h, w))
            query = layer(query, query_pos, memory, memory_pos, attn_mask)
            mask_logits, class_logits = predictor(query, mask_features)  # prediction i+1
            predictions.append((mask_logits, class_logits))

        return predictions, query                                       # len = num_layers + 1