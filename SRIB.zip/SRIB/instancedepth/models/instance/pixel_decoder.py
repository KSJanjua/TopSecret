from __future__ import annotations

import math
from typing import List,Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

def build_2d_sincos_pos_embed(c: int, h: int, w: int, device, dtype) -> torch.Tensor :
    """Return (1,C,H,W) sinusoidal position embedding"""
    assert c%4==0, "channels must be divisible by 4 for 2D sincos pos embed"
    y=torch.arange(h,device=device,dtype=dtype)
    x=torch.arange(w,device=device,dtype=dtype)
    yy,xx=torch.meshgrid(y,x,indexing="ij")
    quarter=c//4
    omega=torch.arange(quarter,device=device,dtype=dtype)/quarter
    omega=1.0/(10000**omega)                                            # (quarter,)
    out_x=xx.flatten()[:,None]*omega[None,:]                            # (HW,quarter)
    out_y=yy.flatten()[:,None]*omega[None,:]
    pe=torch.cat(
        [out_x.sin(),out_x.cos(),out_y.sin(),out_y.cos()], dim=1        # (HW,C)
    )
    return pe.transpose(0,1).reshape(1,c,h,w)

class PixelDecoder(nn.Module):
    """FPN-style pixel decoder producing mask features + multi-scale feats."""
    
    def __init__(
            self,
            in_channels: int,
            hidden_dim: int=256,
            num_scales: int=3,
            num_transformer_feats: int=3,
    ) -> None:
        super().__init__()
        self.hidden_dim=hidden_dim
        self.num_transformer_feats=num_transformer_feats
        self.lateral=nn.ModuleList(
            [
                nn.Conv2d(in_channels,hidden_dim,kernel_size=1) for _ in range(num_scales)
            ]
        )
        self.output_conv=nn.ModuleList(
            [
                nn.Conv2d(hidden_dim,hidden_dim,kernel_size=3,padding=1) for _ in range(num_scales)
            ]
        )
        self.mask_proj=nn.Conv2d(hidden_dim,hidden_dim,kernel_size=1)
    
    def forward(self,feats: List[torch.Tensor]) -> Tuple[torch.Tensor,List[torch.Tensor]]:
        """feats: [f_coarse,...,f_fine] -> (mask_features,multi_scale_feats)"""
        # Top-down FPN (coarse->Fine)
        laterals=[lat(f) for lat,f in zip(self.lateral,feats)]
        out=[self.output_conv[0](laterals[0])]
        for i in range(1,len(laterals)):
            up=F.interpolate(out[-1],size=laterals[i].shape[-2:],mode="bilinear",align_corners=False)
            out.append(self.output_conv[i](laterals[i]+up))
        #out is coarse -> fine; finest is last
        mask_features=self.mask_proj(out[-1])               # (B,C,H/s_fine,W/s_fine)

        #find the coarsest num_transformer_feats: mapsto the transformer decoder
        ms=out[:self.num_transformer_feats]
        return mask_features,ms