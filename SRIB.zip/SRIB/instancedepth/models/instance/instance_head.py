# from __future__ import annotations

# from dataclasses import dataclass, field
# from typing import Dict, List, Optional

# import torch 
# import torch.nn as nn
# import torch.nn.functional as F

# from .pixel_decoder import PixelDecoder, build_2d_sincos_pos_embed
# from .query_fusion import QueryFusion
# from .transformer_decoder import TransformerDecoder

# @dataclass
# class InstanceHeadConfig:
#     in_channels: int=256        # channels of incoming decoder feats
#     hidden_dim: int=256
#     num_queries: int=100
#     num_classes: int=1
#     num_scales: int=3
#     num_transformer_feats: int=3
#     num_decoder_layers: int=9
#     num_heads: int=8
#     ffn_hidden: int=2048
#     dropout: float=0.0
#     max_depth: float=10.0
#     mask_threshold: float=0.5

# class InstanceDepthLayerHead(nn.Module):
#     def __init__(self,cfg: InstanceHeadConfig) -> None:
#         super().__init__()
#         self.cfg=cfg
#         c=cfg.hidden_dim

#         self.pixel_decoder=PixelDecoder(
#             in_channels=cfg.in_channels,
#             hidden_dim=c,
#             num_scales=cfg.num_scales,
#             num_transformer_feats=cfg.num_transformer_feats,
#         )

#         # Two task-specific query embedding sets + their learned positional embeds.
#         self.mask_query_feat=nn.Embedding(cfg.num_queries,c)
#         self.depth_query_feat=nn.Embedding(cfg.num_queries,c)
#         self.query_pos=nn.Embedding(cfg.num_queries,c)

#         self.transformer=TransformerDecoder(
#             hidden_dim=c,
#             num_heads=cfg.num_heads,
#             num_layers=cfg.num_decoder_layers,
#             ffn_hidden=cfg.ffn_hidden,
#             dropout=cfg.dropout,
#             mask_threshold=cfg.mask_threshold,
#         )
#         self.query_fusion=QueryFusion(c)

#         # predictive heads
#         self.class_head=nn.Linear(c,cfg.num_classes+1)      # +1 for no-object
#         self.mask_embed=nn.Sequential(
#             nn.Linear(c,c),
#             nn.ReLU(inplace=True),
#             nn.Linear(c,c),
#             nn.ReLU(inplace=True),
#             nn.Linear(c,c)
#         )
#         self.depth_head=nn.Sequential(
#             nn.Linear(c,c),
#             nn.ReLU(inplace=True),
#             nn.Linear(c,1)
#         )

#     def _predict(self,mask_q:torch.Tensor, fused_depth_q:torch.Tensor, mask_features:torch.Tensor):
#         """From query features -> (mask_logits, class_logits, depth_layer)"""
#         q_mask=mask_q.permute(1,0,2)
#         q_depth=fused_depth_q.permute(1,0,2)
#         class_logits=self.class_head(q_mask)
#         mask_emb=self.mask_embed(q_mask)
#         mask_logits=torch.einsum("bnc,bchw->bnhw",mask_emb,mask_features)   #(B,N,Hf,Wf)
#         depth_layer=torch.sigmoid(self.depth_head(q_depth))*self.cfg.max_depth #(B,N,1)
#         return mask_logits,class_logits,depth_layer
    
#     def forward(
#             self,
#             decoder_feats: List[torch.Tensor],                  # [f8,f4,f2], coarse->fine
#             init_depth: Optional[torch.Tensor]=None,            # (B,1,H,W) HDI prior (unused by default)
#     ) -> Dict[str,object] :
#         b=decoder_feats[0].shape[0]
#         device,dtype=decoder_feats[0].device, decoder_feats[0].dtype

#         mask_features, ms_feats=self.pixel_decoder(decoder_feats)
#         ms_pos=[
#             build_2d_sincos_pos_embed(f.shape[1],f.shape[2],f.shape[3],device,dtype).expand(b,-1,-1,-1)
#             for f in ms_feats
#         ]

#         n=self.cfg.num_queries
#         mask_q=self.mask_query_feat.weight.unsqueeze(1).repeat(1,b,1)       #(N,B,C)
#         depth_q=self.depth_query_feat.weight.unsqueeze(1).repeat(1,b,1)     #(N,B,C)
#         qpos=self.query_pos.weight.unsqueeze(1).repeat(1,b,1)

#         #Shared transformer decoder over both query streams (concatenated along N)
#         cat_q=torch.cat([mask_q,depth_q],dim=0)                             #(2N,B,C)
#         cat_pos=torch.cat([qpos,qpos],dim=0)
#         cat_q=self.transformer(cat_q,cat_pos,ms_feats,ms_pos,mask_features)
#         mask_q_out,depth_q_out=cat_q[:n],cat_q[n:]                          #(split back)

#         fused_depth_q=self.query_fusion(mask_q_out,depth_q_out)             #(N,B,C)

#         mask_logits,class_logits,depth_layer=self._predict(mask_q_out,fused_depth_q,mask_features)

#         return {
#             "pred_masks": mask_logits,          # (B,N,Hf,Wf)
#             "pred_logits": class_logits,        # (B,N,K+1)
#             "pred_depth": depth_layer,          # (B,N,1)
#             "mask_features": mask_features,     # (B,C,Hf,Wf)
#         }

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn

from .pixel_decoder import PixelDecoder, build_2d_sincos_pos_embed
from .query_fusion import QueryFusion
from .transformer_decoder import TransformerDecoder


@dataclass
class InstanceHeadConfig:
    in_channels: int = 256
    hidden_dim: int = 256
    num_queries: int = 32          
    num_classes: int = 1
    num_scales: int = 3
    num_transformer_feats: int = 3 # how many multi-scale feature maps from the pixel decoder are passed to the transoformer decoder for cross-attention
    num_decoder_layers: int = 9
    num_heads: int = 8
    ffn_hidden: int = 2048
    dropout: float = 0.0
    max_depth: float = 10.0
    mask_threshold: float = 0.5


class InstanceDepthLayerHead(nn.Module):
    def __init__(self, cfg: InstanceHeadConfig) -> None:
        super().__init__()
        self.cfg = cfg
        c = cfg.hidden_dim

        self.pixel_decoder = PixelDecoder(
            in_channels=cfg.in_channels, hidden_dim=c,
            num_scales=cfg.num_scales, num_transformer_feats=cfg.num_transformer_feats,
        )

        # two task-specific query embedding sets + shared learned positional embeds
        self.mask_query_feat = nn.Embedding(cfg.num_queries, c)
        self.depth_query_feat = nn.Embedding(cfg.num_queries, c)
        self.query_pos = nn.Embedding(cfg.num_queries, c)

        self.transformer = TransformerDecoder(
            hidden_dim=c, num_heads=cfg.num_heads, num_layers=cfg.num_decoder_layers,
            ffn_hidden=cfg.ffn_hidden, dropout=cfg.dropout, mask_threshold=cfg.mask_threshold,
        )
        self.query_fusion = QueryFusion(c)

        # prediction heads (owned here; reached by the decoder via _predictor)
        self.decoder_norm = nn.LayerNorm(c)
        self.class_head = nn.Linear(c, cfg.num_classes + 1)         # +1 no-object
        self.mask_embed = nn.Sequential(
            nn.Linear(c, c), nn.ReLU(inplace=True),
            nn.Linear(c, c), nn.ReLU(inplace=True), nn.Linear(c, c),
        )
        self.depth_head = nn.Sequential(
            nn.Linear(c, c), nn.ReLU(inplace=True), nn.Linear(c, 1),
        )

    # predictor
    def _predictor(self, query: torch.Tensor, mask_features: torch.Tensor
                   ) -> Tuple[torch.Tensor, torch.Tensor]:
        """(Nq,B,C) -> (B,Nq,Hf,Wf) mask logits, (B,Nq,K+1) class logits.

        Used by the decoder for BOTH the per-layer attention mask and the output,
        so attention and prediction use the same mask.
        """
        q = self.decoder_norm(query).permute(1, 0, 2)               # (B,Nq,C)
        class_logits = self.class_head(q)                           # (B,Nq,K+1)
        mask_emb = self.mask_embed(q)                               # (B,Nq,C)
        mask_logits = torch.einsum("bnc,bchw->bnhw", mask_emb, mask_features)
        return mask_logits, class_logits

    # forward
    def forward(
        self,
        decoder_feats: List[torch.Tensor],          # [f8,f4,f2], coarse->fine
        init_depth: Optional[torch.Tensor] = None,  # (B,1,H,W) HDI prior (unused by default)
    ) -> Dict[str, object]:
        b = decoder_feats[0].shape[0]
        device, dtype = decoder_feats[0].device, decoder_feats[0].dtype

        mask_features, ms_feats = self.pixel_decoder(decoder_feats)
        ms_pos = [
            build_2d_sincos_pos_embed(f.shape[1], f.shape[2], f.shape[3], device, dtype).expand(b, -1, -1, -1)
            for f in ms_feats
        ]

        n = self.cfg.num_queries
        mask_q = self.mask_query_feat.weight.unsqueeze(1).repeat(1, b, 1)   # (N,B,C)
        depth_q = self.depth_query_feat.weight.unsqueeze(1).repeat(1, b, 1)  # (N,B,C)
        qpos = self.query_pos.weight.unsqueeze(1).repeat(1, b, 1)
        cat_q = torch.cat([mask_q, depth_q], dim=0)                         # (2N,B,C)
        cat_pos = torch.cat([qpos, qpos], dim=0)

        # shared decoder over both streams; deep-supervised predictions returned
        predictions, final_q = self.transformer(
            cat_q, cat_pos, ms_feats, ms_pos, mask_features, self._predictor)

        # depth layer from the FINAL fused (mask + depth) queries
        final_mask_q, final_depth_q = final_q[:n], final_q[n:]
        fused = self.query_fusion(final_mask_q, final_depth_q)              # (N,B,C), normed
        depth_layer = torch.sigmoid(self.depth_head(fused.permute(1, 0, 2))) * self.cfg.max_depth  # (B,N,1)

        # final mask/class = last prediction, mask stream (first N of the 2N queries)
        final_mask_logits = predictions[-1][0][:, :n]
        final_class_logits = predictions[-1][1][:, :n]
        aux = [{"pred_masks": p[0][:, :n], "pred_logits": p[1][:, :n]}
               for p in predictions[:-1]]

        return {
            "pred_masks": final_mask_logits,        # (B,N,Hf,Wf)
            "pred_logits": final_class_logits,      # (B,N,K+1)
            "pred_depth": depth_layer,              # (B,N,1)
            "mask_features": mask_features,         # (B,C,Hf,Wf)
            "aux_outputs": aux,                     # per-layer for deep supervision
        }