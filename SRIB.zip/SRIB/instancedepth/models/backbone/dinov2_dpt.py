"""
DINOv2 backbone with a DPT-style reassemble neck

Paper Specified:
Sec 4.3 uses a pretrained DINOv2 backbone for feature extraction;
the ablation baseline (Sec. 5.3) is a Depth-Anything-V2-Encoder + DPT decoder, and DA-V2 = DINO v2 + DPT

Strongly Inferred: 
The 1/8, 1/4, 1/2 multi-scale features in Fig. 5 are recovered from single-stride ViT tokens via the 
standard DPT "reassemble" operation (Ranftl et al., DPT [42]): tokens from several transformer layer
are projected, reshaped to a spatial grid, then resampled to the target strides.

Tensor flow (ViT-L/14, input 518x518 -> 37x37 patch grid, embed_dim=1024)
    rgb                             (B,3,H,W)
    DINOv2 tokens (per layer)       (B,Np,C_vit)            Np=(H/14)*(W/14)
    reshape to grid                 (B,C_vit,H/14,W/14)
    reassemble + resample ->
        f8 (stride 8)               (B,C_out,H/8,W/8)
        f4 (stride 4)               (B,C_out,H/4,W/4)
        f2 (stride 2)               (B,C_out,H/2,W/2)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List,Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

@dataclass
class BackboneConfig:
    """Configuration for the DINOv2 + DPT neck."""

    model_name: str="vit_large_patch14_dinov2.lvd142m"
    out_channels: int=256
    out_strides: Tuple[int,...]=(8,4,2)
    hook_layers: Tuple[int,...]=(11,17,23)
    patch_size: int=14
    pretrained: bool=True
    freeze: bool=False

class _Reassemble(nn.Module):
    """
    DPT reassemble: project tokens and resample to a target stride.

    Input: (B,C_vit,Hg,Wg) reshaped ViT tokens on the patch grid
    Output: (B,C_out,H/stride,W/stride)
    """

    def __init__(self,in_channels: int, out_channels: int, stride: int) -> None:
        super().__init__()
        self.stride=stride
        self.project=nn.Conv2d(in_channels,out_channels,kernel_size=1)
        self.refine=nn.Conv2d(out_channels,out_channels,kernel_size=3, padding=1)

    def forward(self,tokens_grid: torch.Tensor, out_hw: Tuple[int,int]) -> torch.Tensor:
        x=self.project(tokens_grid)
        x=F.interpolate(x,size=out_hw,mode="bilinear",align_corners=False)
        x=self.refine(x)
        return x
        
class DINOv2DPTBackbone(nn.Module):
    """DINOv2 encoder exposing 1/8, 1/4, 1/2 multi-scale features"""

    def __init__(self,cfg: BackboneConfig) -> None:
        super().__init__()
        self.cfg=cfg
        import timm # local import

        import os

        _overlay = None
        _w = os.environ.get("DINOV2_WEIGHTS")     # local DINOv2 weights (offline cluster)
        if _w:
            _overlay = dict(file=_w)

        self.vit = timm.create_model(
            cfg.model_name,
            pretrained=cfg.pretrained,
            num_classes=0,
            dynamic_img_size=True,
            pretrained_cfg_overlay=_overlay,       # None -> normal behavior
        )
        self.embed_dim: int=self.vit.embed_dim
        self.patch_size: int=cfg.patch_size

        assert len(cfg.hook_layers) == len(cfg.out_strides),("hook_layers and out_strides must have equal length")

        self.reassembles=nn.ModuleList(
            [_Reassemble(self.embed_dim,cfg.out_channels,s) for s in cfg.out_strides]
        )

        if (cfg.freeze):
            self.freeze_backbone()

    #utils
    def freeze_backbone(self) -> None:
        for p in self.vit.parameters():
            p.requires_grad_(False)
        self.vit.eval()
    
    def unfreeze_backbone(self) -> None:
        for p in self.vit.parameters():
            p.requires_grad_(True)

    def _grid_hw(self,h: int,w: int) -> Tuple[int,int]:
        return h//self.patch_size,w//self.patch_size
    
    def _hook_indices(self) -> List[int]:
        return sorted(set(self.cfg.hook_layers))
    
    #forward
    def forward(self,rgb:torch.Tensor) -> List[torch.Tensor]:
        """
        Return [f8,f4,f2], coarse -> fine.
        rgb: (B,3,H,W) with H,W divisible by patch_size
        """
        b,_,h,w=rgb.shape
        assert h%self.patch_size==0 and w%self.patch_size==0, (
            f"Input H,W ({h},{w}) must be divisible by patch_size {self.patch_size}."
        ) 
        hg,wg=self._grid_hw(h,w)
        feats=self.vit.get_intermediate_layers(
            rgb,n=self._hook_indices(), reshape=False,norm=True,
        )
        layer_map=dict(zip(self._hook_indices(),feats))

        outputs: List[torch.Tensor]=[]

        for stride,hook,reassemble in zip(self.cfg.out_strides, self.cfg.hook_layers,self.reassembles):
            tokens=layer_map[hook]                      # (B,Np,C_vit)
            grid=tokens.transpose(1,2).reshape(b,self.embed_dim,hg,wg)
            out_hw=(h//stride,w//stride)
            outputs.append(reassemble(grid,out_hw))     # (B,C_out,H/s,W/s)
        return outputs