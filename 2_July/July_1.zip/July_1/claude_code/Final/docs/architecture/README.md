# InstanceDepth — As-Built Architecture Diagrams

These diagrams document the repository **exactly as implemented** (not the paper's
conceptual architecture — for that see `presentation/diagrams/`). Tensor shapes use
the default configuration ([instancedepth/configs/instance_depth.yaml](../../instancedepth/configs/instance_depth.yaml)):
input **504×896**, `B`=batch, `C=256`, `N=32` queries, `K=1` class, `rd=5` depth
ranges, DINOv2 ViT-L/14 (embed 1024, patch grid 36×64), ROI 7×7.

> If your data is 720×1280 and you keep exact 16:9, the spatial numbers scale with
> the chosen input size; the channel/query/ROI dimensions do not change.

## Files
| File | Scope |
|---|---|
| [00_master_dataflow.mmd](00_master_dataflow.mmd) | End-to-end: data engine → dataset → model (3 phases) → losses / eval / inference; config deps |
| [01_data_engine_sam3.mmd](01_data_engine_sam3.mmd) | SAM3 tracking → identity → annotate → `gid_custom`; dataset loading + collate |
| [02_backbone.mmd](02_backbone.mmd) | DINOv2 ViT-L/14 + DPT/RefineNet neck → f8/f4/f2, with shapes and freeze policy |
| [03_phase1_hdi.mmd](03_phase1_hdi.mmd) | Range decoder (patch attention) + S/D/C heads + iterative Eqs 1–4 + Phase-1 losses |
| [04_phase2_instance.mmd](04_phase2_instance.mmd) | MSDeformAttn pixel decoder + two-stream masked-attention decoder + query fusion + matcher + criterion |
| [05_phase3_refine.mmd](05_phase3_refine.mmd) | Pair selection + ROIAlign + Φo (Eqs 8–9) + composite + Phase-3 losses; **gradient/detach legend + known failure points** |

## Reading conventions
- **Solid arrow** = gradient flows through this edge during training.
- **Dashed arrow** = value is used but the gradient is **detached** (esp. Phase 3).
- Node colors: blue = source/input, light-blue = process, cyan = output tensor,
  green = key prediction, red = loss, yellow = note, orange = stored artifact.
- Every major node lists its output tensor shape; resolution/channel changes are on
  the node or edge labels.

## Rendering to SVG/PNG
The `.mmd` files render directly in VS Code (Mermaid preview), GitHub, and mermaid.live.
To export images with mermaid-cli (Node ≥ 18 required):

```bash
cd docs/architecture
for f in *.mmd; do npx -y @mermaid-js/mermaid-cli -i "$f" -o "${f%.mmd}.svg" -w 2400 -H 1600; done
```

(First run downloads mermaid-cli + a headless Chromium; needs network access.)
