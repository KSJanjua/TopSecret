# InstanceDepth — Project Presentation

Deliverables in this folder:

```
presentation/
├── InstanceDepth_Presentation.pptx   ← editable deck (15 slides, 16:9)
├── diagrams/                          ← Mermaid sources (one per diagram)
│   ├── 01_dataset_preparation.mmd
│   ├── 02_system_pipeline.mmd
│   ├── 03_repository_structure.mmd
│   ├── 04_model_architecture.mmd
│   ├── 05_phase_training.mmd
│   └── 06_instance_decoder.mmd
├── assets/                            ← drop rendered PNGs + screenshots here
└── README.md
```

The deck contains **only work actually completed** in the repository. No results
are invented — every results/graph slot is a labelled placeholder.

---

## 1. Fill the blanks

- **Team banner** — every slide has a thin navy banner at the top: `Team: ____`.
  Fill in your team name (edit once, or use *Insert → Header/Footer* style edit).
- **Dashed teal boxes** are placeholders. Two kinds:
  - `DIAGRAM PLACEHOLDER` → replace with the rendered Mermaid diagram named on it.
  - `IMAGE PLACEHOLDER` → replace with a screenshot / plot / result image.

---

## 2. Render the Mermaid diagrams and insert them

Each diagram is a standalone `.mmd`. Render to PNG/SVG, then drag the image onto
the matching `DIAGRAM PLACEHOLDER` box on the indicated slide.

| Diagram file | Goes on slide | Suggested render size |
|---|---|---|
| `01_dataset_preparation.mmd` | **Slide 6 — Dataset Preparation Pipeline** | wide  (1600 × 700) |
| `02_system_pipeline.mmd`     | **Slide 7 — Overall System Pipeline**     | wide  (1700 × 700) |
| `03_repository_structure.mmd`| **Slide 8 — Repository Structure**        | tall  (1500 × 950) |
| `04_model_architecture.mmd`  | **Slide 9 — Model Architecture**          | large (1700 × 1000) |
| `05_phase_training.mmd`      | **Slide 10 — Phase-wise Implementation**  | wide  (1700 × 800) |
| `06_instance_decoder.mmd`    | **Slide 9 (inset) / detail**              | square(1400 × 900) |

### Option A — Mermaid CLI (local)
```bash
npm install -g @mermaid-js/mermaid-cli
cd presentation/diagrams
mmdc -i 02_system_pipeline.mmd -o ../assets/02_system_pipeline.png -w 1700 -H 700 -b white
# repeat for each .mmd
```

### Option B — no install
Paste a `.mmd` into <https://mermaid.live>, export PNG/SVG (white background),
save into `assets/`.

> The diagrams are pre-styled with the project palette via `classDef`, so they
> match the slide theme automatically. Use a **white background** when exporting.

---

## 3. Image placeholders to fill (after training / experiments)

| Slide | Placeholder |
|---|---|
| 1 (Title) | Hero qualitative result (RGB / depth / overlay) |
| 2 (Problem) | Occlusion failure example |
| 5 (Dataset) | Input RGB · Input depth · Instance masks · Tracking IDs |
| 11 (Progress) | TensorBoard loss curves · Quantitative results table · Model output |
| 13 (Future) | Qualitative comparison vs DA-V2 / ZoeDepth |
| 14 (Closing) | Team / contact details |

---

## 4. Slide index

1. Project Overview · 2. Problem Statement · 3. Motivation ·
4. InstanceDepth Paper Overview · 5. Dataset Overview ·
6. Dataset Preparation Pipeline · 7. Overall System Pipeline ·
8. Repository Structure · 9. Model Architecture ·
10. Phase-wise Implementation · 11. Current Progress ·
12. Current Challenges · 13. Future Work · (+ title & closing)

---

## 5. Colour theme (for any edits you add)

| Role | Hex |
|---|---|
| Titles / outlines / text | `#0B2B44` |
| Header fills | `#277EAF` `#0070C0` `#0E7BC2` |
| Accent (placeholders, highlights) | `#18A585` |
| Light box fills | `#9BE5FF` `#D1F3FF` `#CCFFFF` |
| Background | white |

Keep titles/outlines dark and box fills light, as in the existing slides.
