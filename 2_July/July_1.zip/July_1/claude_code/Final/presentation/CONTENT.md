# InstanceDepth — Presentation Content (story-driven)

Notation:
- `[DIAGRAM: file.mmd]` → use a diagram here (existing file in `diagrams/`, or *create* if marked NEW).
- `[PLACEHOLDER: …]` → leave a sized box for a screenshot / plot / result image.
- All facts below are grounded in the current repo / paper / meta.json. No results are claimed.

---

## Slide 1 — Title
- **InstanceDepth** — Instance-Level Video Depth in Groups Beyond Occlusions
- Faithful reproduction + re-implementation on a **custom RGB-D dataset** (ICCV 2025, Liang et al.)
- Chips: *Monocular metric depth · Occlusion-aware · Mask2Former-based · Custom RGB-D*
- `[PLACEHOLDER: hero qualitative result — RGB | depth | instance overlay]`

---

## Slide 2 — Project Story (one-glance arc)
- Prefer a **flow strip** over text:
- `[DIAGRAM: NEW 11_story_arc.mmd]` →
  `Custom dataset + annotation` → `Initial implementation` → `Training failures` →
  `Repository audit` → `Architecture rebuild` → `Validated pipeline` → `Training (next)`
- One line: *"What we built, what broke, what we fixed, where we are."*

---

## Slide 3 — InstanceDepth Paper (the target)
- Two-stage, monocular, depth-sensor supervised (NOT stereo)
- Stage 1: **Holistic Depth Init** — coarse depth + range refinement (Eqs 1–4)
- Stage 2: **Instance-Aware Rectification** — Mask2Former masks + depth layers (Eqs 5–7), occlusion-pair refinement (Eqs 8–12)
- 3 progressive phases: **55k / 25k / 25k** iters @ lr **1e-5 / 1e-5 / 1e-6**
- `[DIAGRAM: 02_system_pipeline.mmd]` (compact, as the paper overview)

---

## Slide 4 — Custom RGB-D Dataset vs GID
- Use a **comparison table** (no prose):

| | GID (paper) | Our custom dataset |
|---|---|---|
| Videos / frames | 112 / 101,500 | **306 / 50,323** |
| Avg objects / frame | 8.7 | **2.34** |
| Categories | humans, balls, rackets, animals | **person only (id 0)** |
| Depth source | ToF sensors (RealSense D455, Azure Kinect) | **ZED stereo — left camera** |
| Masks / tracking | SAM + DEVA | **SAM3 (single pass)** |
| Train / test | 80 / 20 % (video-level) | **245 / 61** (same 20 % policy) |
| Depth range | 0.01–10 m | 0.01–10 m |

- Key implications: stereo-derived depth (weaker at occlusions), fewer/denser people, person-only → **not 1:1 comparable to the paper's tables**
- `[PLACEHOLDER: depth-range histogram — 0-2 m dominates (67,778 objects)]`

---

## Slide 5 — Dataset Preparation & Annotation Pipeline *(completed earlier)*
- `[DIAGRAM: 01_dataset_preparation.mmd]` (primary content of the slide)
- Short captions only:
  - `discover` — pair RGB ↔ depth by frame number
  - `SAM3` — concept-prompted video segmentation (person, floor/ground)
  - `identity` — cross-concept dedup + IoU re-link + short-track filter
  - `annotate` — depth layer = **mean valid depth in mask**; nearest-depth flatten; bbox + ground mask
  - `finalize` — 20 % video-level split → `meta.json`
- Output: `annotations.json` + uint16 instance masks → **306 videos processed**
- `[PLACEHOLDER: sample annotation — RGB | object mask | ground mask | depth]`

---

## Slide 6 — Initial Repository & Implementation *(before the rebuild)*
- `[DIAGRAM: NEW 07_initial_architecture.mmd]` — original module graph, annotate the weak spots in a different color
- Bullets (what existed):
  - 3-phase InstanceDepth scaffold present (HDI + instance head + refinement)
  - Backbone "DPT" = **single 1/14 ViT grid bilinearly resized** to 3 scales (no true multi-scale)
  - Instance head = Mask2Former-style but **plain FPN** pixel decoder
  - **2N queries (mask + depth) through one shared decoder** + query fusion
  - **`utils/` empty** → `train.py` / `evaluate.py` could not even import
  - Duplicate HDI module, dead build factories, many one-off viz/diagnostic scripts

---

## Slide 7 — Issues Encountered During Training
- Observed failure modes (reported symptoms):
  - Incomplete person masks
  - Missing body parts
  - Multiple people **merged** into one instance
  - Poor instance separation
  - Identity confusion during training
- `[PLACEHOLDER: qualitative failure grid — merged masks / missing limbs]`
- `[PLACEHOLDER: early TensorBoard curves showing the issue (if available)]`
- *Note: symptoms motivated the audit — not yet re-measured after the rebuild.*

---

## Slide 8 — Repository Audit & Analysis
- Objective audit (assume nothing correct until verified). Use a **3-column table**:

| Keep | Delete | Rewrite |
|---|---|---|
| matcher, losses, refinement, HDI heads | 4 duplicate visualizers | backbone (DPT neck) |
| transformer-decoder core (M2F-faithful) | 4 one-off diagnostics | pixel decoder (FPN→MSDeformAttn) |
| data_engine (most) | `hdi_vitl.yaml`, dead build code | instance head (decouple streams) |
| configs / registry | duplicate HDI class | `gid_dataset.py`, `identity.py` |

- `[DIAGRAM: NEW 08_audit_rootcause.mmd]` — map **symptom → root cause** (next slide)

---

## Slide 9 — Root Causes (audit findings)
- `[DIAGRAM: NEW 08_audit_rootcause.mmd]` as the main visual; bullets as legend:
  1. **Backbone**: no real high-res features (1/14 grid, interpolate-only) + frozen in phase 2 → soft/incomplete masks
  2. **Data loader**: dropped GT instances when depth invalid / `<64 px` → visible people deleted from supervision → **missing / merged**
  3. **Data-engine identity**: aggressive re-link + nearest-depth flatten → ID confusion / truncation
  4. **Weak pixel decoder**: plain FPN, near-identical scales → poor separation
  5. **Unsupervised depth-query stream** corrupting the mask stream via shared attention
  6. **Blockers / drift**: empty `utils/`, `partition_meters` 1.0 vs paper-best 2.0

---

## Slide 10 — Architecture Improvements (after audit)
- Prefer a **before → after** diagram:
- `[DIAGRAM: NEW 09_before_after.mmd]` (left = old module, right = new module, per row)
- `[DIAGRAM: 04_model_architecture.mmd]` for the full "after" architecture
- Highlights:
  - **Backbone** → real DPT reassemble + RefineNet fusion (genuine 1/8·1/4·1/2 features)
  - **Pixel decoder** → true **Mask2Former MSDeformAttn** (pure-PyTorch core); coarse encoder/decoder, 1/2 mask features via FPN
  - **Instance head** → **two-stream decoder**, block self-attention so the mask stream is **independent of depth queries**
- `[DIAGRAM: 06_instance_decoder.mmd]` (inset for the two-stream fix)

---

## Slide 11 — Key Code Changes & Why
- **Table** (file → change → why), no prose:

| Module | Change | Why |
|---|---|---|
| `backbone/dinov2_dpt.py` | interpolate-only → DPT + RefineNet fusion | real multi-scale detail; sharper masks |
| `instance/pixel_decoder.py` | FPN → MSDeformAttn (M2F) | faithful decoder; better separation |
| `instance/transformer_decoder.py` + `instance_head.py` | block self-attn; decouple depth stream | masks no longer corrupted (verified bit-exact) |
| `data/gid_dataset.py` | keep mask when depth invalid (depth=0) | stop deleting visible people |
| `data_engine/identity.py` | temporal-disjoint + non-overwriting re-link | no co-occurring-track merges |
| `utils/metrics.py`, `instance_metrics.py` | created | unblock train / eval |
| `configs/instance_depth.yaml` | partition 1.0 → 2.0 | paper-best (Table 5) |
| `train.py` / `run_pipeline.py` | bf16 AMP, single-command 3-phase + per-phase eval | 40 GB-efficient, reproducible |

---

## Slide 12 — Current State (verified, no results yet)
- Two cards: **Implemented** | **Validated (CPU)**
  - Implemented: backbone, MSDeformAttn decoder, two-stream head, data fixes, metrics, AMP, pipeline
  - Validated: full model builds (~353 M params); all 3 phases forward/backward; checkpoint chaining **0 missing / 0 unexpected**; bf16 numerically safe; deformable core numerically verified; mask-stream decoupling **bit-exact**
- **Full-scale training not yet run → no quantitative results.**
- `[PLACEHOLDER: TensorBoard loss curves — P1 / P2 / P3]`
- `[PLACEHOLDER: quantitative results table — RMS / REL / σ]`
- `[PLACEHOLDER: model output — init depth vs refined depth]`

---

## Slide 13 — Remaining Work & Next Steps
- Run full **3-phase training** on the 40 GB GPU (`python run_pipeline.py --data-root gid_custom --out runs`)
- Collect TensorBoard curves + fill quantitative tables
- Add **instance-AP** evaluation (depth metrics only today)
- *Optional, paper-faithful:* use the **right RGB offline** to refine depth GT (model stays monocular)
- Resolution sweep (504×896 → higher) for sharper masks/depth
- Cross-dataset check (NYUDv2) for generalization
- `[PLACEHOLDER: qualitative comparison vs DA-V2 / ZoeDepth (after training)]`

---

## Slide 14 — Closing
- One-line summary: *dataset + annotation done · implementation audited and rebuilt to be paper-faithful and validated · full training is the next step*
- `[PLACEHOLDER: team / contact]`

---

### Diagrams referenced
Existing (`diagrams/`): `01_dataset_preparation`, `02_system_pipeline`, `03_repository_structure`,
`04_model_architecture`, `05_phase_training`, `06_instance_decoder`.
Suggested NEW: `07_initial_architecture`, `08_audit_rootcause`, `09_before_after`, `11_story_arc`.

### Placeholder inventory (sized boxes only — no dummy images)
Input RGB · Input depth · Instance masks · Tracking IDs · Annotation sample ·
Failure grid · TensorBoard curves · Quantitative table · Model output (init vs refined) ·
Qualitative comparison vs baselines · Depth-range histogram · Team/contact.
