# InstanceDepth — Complete Beginner Execution Guide

Follow these steps in order. Steps 1–4 are one-time setup; 5–9 are the actual
pipeline. Run every command from a terminal, and after Step 4 always from the
repository root (`~/InstanceDepthRepo`).

---
## 1. What you need before starting

- A Linux machine (or Windows + WSL2) with an NVIDIA GPU (>= 16 GB VRAM
  recommended for ViT-L training; 24 GB comfortable) and CUDA drivers installed
  (`nvidia-smi` must print your GPU).
- Your dataset at some path, structured as:
  `InstanceDepth/Dataset/Batch 1 ... Batch 10/<timestamp>/{left_rgb, left_filled, left_filled_np}`
- Your SAM3 checkout (github.com/facebookresearch/sam3) with its checkpoint
  downloaded via your HuggingFace access.
- The 25 flat model `.py`/`.yaml` files you uploaded, in one folder
  (call it `~/flat_files`).
- This delivery, unzipped (call it `~/instancedepth_delivery`).

## 2. Create the Python environment

```bash
conda create -n instdepth python=3.12 -y
conda activate instdepth
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install -r ~/instancedepth_delivery/requirements.txt
pip install -e /path/to/your/sam3        # the SAM3 repo folder
python -c "import torch; print(torch.cuda.is_available())"   # must print True
```

## 3. Assemble the repository (one command)

```bash
bash ~/instancedepth_delivery/setup_repo.sh \
     ~/flat_files ~/instancedepth_delivery ~/InstanceDepthRepo
cd ~/InstanceDepthRepo
```

This arranges your flat files into the package tree their imports expect and
substitutes 4 patched files (matcher resize fix; Eq. 3 signed-correction fix in
holistic_depth/instance_depth/run_config — see PATCHES.md). Expect "44" files.

## 4. Edit one config file

Open `instancedepth/configs/gid_custom.yaml` and set:
- `dataset_root:` -> absolute path to your `InstanceDepth/Dataset`
- `sam3.checkpoint_path:` -> path to your SAM3 `.pt` checkpoint
- `sam3.object_prompts:` -> the object categories in your videos
  (default `["person"]`; if you add more, also raise `instance.num_classes`
  in `instancedepth/configs/instance_depth.yaml` to match the count).

## 5. Dry-run the data engine (no GPU, ~1 min)

Temporarily set `sam3.backend: "mock"` in gid_custom.yaml, then:

```bash
python -m instancedepth.data_engine.run_generate \
    --config instancedepth/configs/gid_custom.yaml --limit 1
```

PASS criteria: no errors; a `gid_custom/` folder appears; the log shows
`depth unit auto-detect: median raw=... -> scale=...` with a sensible scale
(0.001 if your files store millimeters, 1 if meters). If wrong, set
`depth.unit: "mm"` or `"m"` explicitly. Then set `backend: "native"` back.

## 6. Generate annotations with SAM3 (GPU; the long offline job)

```bash
# pilot on 2 sequences, then LOOK at gid_custom/**/preview/*.jpg overlays
python -m instancedepth.data_engine.run_generate \
    --config instancedepth/configs/gid_custom.yaml --limit 2
# full run
python -m instancedepth.data_engine.run_generate \
    --config instancedepth/configs/gid_custom.yaml
```

Output: per sequence `object_masks/` (uint16 PNG, pixel=track id),
`ground_masks/`, `annotations.json`; globally `train.txt`, `test.txt` (20%
videos), `meta.json`. Tune `min_object_score` / prompts if overlays look bad.

## 7. Train — three phases in order (paper Sec. 4.3)

```bash
# Phase 1: depth pretraining (defaults: 55k iters, lr 1e-5)
python train.py --model-config instancedepth/configs/instance_depth.yaml \
    --data-root gid_custom --phase 1 --batch-size 4 --out runs/phase1

# Phase 2: instance decoder, encoder frozen (25k, 1e-5)
python train.py --model-config instancedepth/configs/instance_depth.yaml \
    --data-root gid_custom --phase 2 --batch-size 4 \
    --init-from runs/phase1/ckpt_final.pth --out runs/phase2

# Phase 3: occlusion-aware refinement, instance head frozen (25k, 1e-6)
python train.py --model-config instancedepth/configs/instance_depth.yaml \
    --data-root gid_custom --phase 3 --batch-size 4 \
    --init-from runs/phase2/ckpt_final.pth --out runs/phase3
```

Notes: out-of-memory -> lower `--batch-size` or `--image-size 392 392`.
Interrupted -> add `--resume runs/phaseN/ckpt_XXXXXX.pth`. Early phase-3
`obj=0 dist=0` lines are normal until the instance head is confident enough to
pass the paper's pair-selection thresholds.

## 8. Evaluate (paper Table-2 metrics on the test split)

```bash
python evaluate.py --model-config instancedepth/configs/instance_depth.yaml \
    --data-root gid_custom --checkpoint runs/phase3/ckpt_final.pth \
    --split test --out-json results_final.json
# HDI-only ablation:
python evaluate.py --model-config instancedepth/configs/instance_depth.yaml \
    --data-root gid_custom --checkpoint runs/phase1/ckpt_final.pth \
    --split test --use-init-depth --out-json results_hdi.json
```

Prints/saves RMS, REL, RMSlog, Log10, sigma1-3 (lower / lower / lower / lower /
higher is better).

## 9. Optional sanity test of the whole stack without your data

```bash
python ~/instancedepth_delivery/test_e2e.py
```

---
## Troubleshooting quick table

| Symptom | Fix |
|---|---|
| `ModuleNotFoundError: instancedepth` | You're not in `~/InstanceDepthRepo`; `cd` there first |
| `CUDA out of memory` | `--batch-size 2` or `--image-size 392 392` |
| SAM3 import error | `pip install -e /path/to/sam3` inside the conda env |
| SAM3 output key mismatch (repo version drift) | adjust key names in `instancedepth/data_engine/sam3_engine.py::_frame_payload` (one place) |
| depth values look 1000x off | set `depth.unit` explicitly in gid_custom.yaml |
| no instances in annotations | lower `sam3.min_object_score`; check prompts match your scenes |
