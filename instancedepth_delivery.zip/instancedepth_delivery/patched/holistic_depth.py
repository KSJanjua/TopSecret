"""Holistic Depth Initialization (Section 4.1).

    RGB -> DINOv2/DPT backbone -> Depth Range Feature Decoder -> heads (S, D, C)
        -> iterative depth-range refinement (Eqs. 1-4) -> initial holistic depth.

Refinement equations:
    C_i = Sigmoid(Phi_d(F_i, D_i))                              (Eq. 1)
    R_i = sum_{rd} (C_i * S_i)                                  (Eq. 2)
    E_i = 2 * (R_i - 1) * (MAX_d / rd)                          (Eq. 3)
    D_{i+1} = D_i + E_i                                         (Eq. 4)

Faithfulness notes
-------------------
[Paper Specified]  Eqs. 1-4 verbatim; iterate across depth levels; MAX_d divided
                   into rd ranges; coarse depth output.
[Strongly Inferred] Refinement repeats over depth levels = refinement iterations on
                   the shared depth-range features; default num_refine_steps = 3 =
                   number of decoder scales. S renormalized (softmax) so R_i is a
                   confidence-weighted expectation, making (R_i - 1) a signed
                   correction.
[Reasonable Assumption]
                   The same range features F drive every step while D updates each
                   step (Phi_d sees evolving depth); S, C recomputed each iter.

Output dict keys
----------------
    "depth"        : final initial holistic depth     (B, 1, H, W)
    "depth_stages" : depth maps per iteration          each (B, 1, h, w)
    "range_logits" : range segmentation logits         (B, rd, h, w)
    "range_probs"  : range segmentation distribution   (B, rd, h, w)
    "feat_hw"      : (h, w) of the decoder feature map
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..backbone.dinov2_dpt import BackboneConfig, DINOv2DPTBackbone
from .heads import ConfidenceNet, InitDepthHead, RangeSegHead
from .range_decoder import DepthRangeFeatureDecoder, RangeDecoderConfig


@dataclass
class HDIConfig:
    backbone: BackboneConfig = field(default_factory=BackboneConfig)
    decoder: RangeDecoderConfig = field(default_factory=RangeDecoderConfig)
    max_depth: float = 10.0          # MAX_d, meters (Fig. 2)
    partition_meters: float = 2.0    # Table 5 best -> rd = max_depth / partition
    num_refine_steps: int = 3
    head_hidden: int = 128
    # Eq. 3 as printed (E = 2*(R-1)*step with R in [0,1]) can only DECREASE
    # depth. True (default) uses the symmetric form E = (2R-1)*step, matching
    # the signed-correction pattern of Eq. 9. See PATCHES.md, finding #2.
    symmetric_range_error: bool = True

    @property
    def num_ranges(self) -> int:
        return max(int(round(self.max_depth / self.partition_meters)), 1)


class HolisticDepthInitialization(nn.Module):
    """Stage 1 of InstanceDepth: coarse scene-level metric depth."""

    def __init__(self, cfg: HDIConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.num_ranges = cfg.num_ranges

        self.backbone = DINOv2DPTBackbone(cfg.backbone)
        self.decoder = DepthRangeFeatureDecoder(cfg.decoder, num_scales=len(cfg.backbone.out_strides))

        c = cfg.decoder.channels
        self.range_seg_head = RangeSegHead(c, self.num_ranges, cfg.head_hidden)
        self.init_depth_head = InitDepthHead(c, cfg.max_depth, cfg.head_hidden)
        self.confidence_net = ConfidenceNet(c, self.num_ranges, cfg.head_hidden)

        self.register_buffer(
            "range_step",
            torch.tensor(cfg.max_depth / self.num_ranges, dtype=torch.float32),
            persistent=False,
        )

    def _refine(self, feats: torch.Tensor, depth: torch.Tensor, range_probs: torch.Tensor) -> torch.Tensor:
        """One refinement iteration implementing Eqs. 1-4."""
        conf = self.confidence_net(feats, depth)              # C_i  Eq.1
        r = (conf * range_probs).sum(dim=1, keepdim=True)     # R_i  Eq.2
        if self.cfg.symmetric_range_error:
            e = (2.0 * r - 1.0) * self.range_step             # signed E_i (see PATCHES.md #2)
        else:
            e = 2.0 * (r - 1.0) * self.range_step             # E_i  Eq.3 literal (<= 0)
        depth_next = (depth + e).clamp(0.0, self.cfg.max_depth)  # D_{i+1} Eq.4
        return depth_next

    def forward(self, rgb: torch.Tensor) -> Dict[str, object]:
        b, _, H, W = rgb.shape
        feats_ms: List[torch.Tensor] = self.backbone(rgb)         # [f8, f4, f2]
        range_feats = self.decoder(feats_ms)                      # (B, C, h, w)
        h, w = range_feats.shape[-2:]

        range_logits, range_probs = self.range_seg_head(range_feats)
        depth = self.init_depth_head(range_feats)

        depth_stages: List[torch.Tensor] = [depth]
        for _ in range(self.cfg.num_refine_steps):
            depth = self._refine(range_feats, depth, range_probs)
            depth_stages.append(depth)

        depth_full = F.interpolate(depth, size=(H, W), mode="bilinear", align_corners=False)
        return {
            "depth": depth_full,
            "depth_stages": depth_stages,
            "range_logits": range_logits,
            "range_probs": range_probs,
            "feat_hw": (h, w),
        }
