#!/usr/bin/env python3
"""
CCD-Net inference (best version). Loads the EMA weights by default (better than
raw weights). Enhances a folder of low-light images; outputs feed evaluate.py.

Usage:
  python infer.py --ckpt experiments/<name>/checkpoints/best.pth \
                  --in-dir dataset/LOLv1/eval15/low --out-dir results/ccdnet \
                  --color-space hvi --base-channels 64
"""
from __future__ import annotations

import argparse, os, os.path as osp
import numpy as np
import torch
import imageio.v2 as imageio

from ccdnet import build_ccdnet
from ccdnet.data import _load_rgb01, _list


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--in-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--color-space", default="hvi", choices=["hvi", "ycbcr"])
    ap.add_argument("--base-channels", type=int, default=64)
    ap.add_argument("--n-blocks", type=int, default=2)
    ap.add_argument("--use-lowrank", action="store_true")
    ap.add_argument("--weights", default="ema", choices=["ema", "model"],
                    help="which weights to load from the checkpoint")
    ap.add_argument("--pad", type=int, default=4)
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    model = build_ccdnet({"base_channels": args.base_channels, "n_blocks": args.n_blocks,
                          "use_lowrank": args.use_lowrank, "color_space": args.color_space}).to(args.device)
    ck = torch.load(args.ckpt, map_location=args.device)
    state = ck.get(args.weights, ck.get("model", ck))
    model.load_state_dict(state)
    model.eval()

    files = _list(args.in_dir)
    print(f"Enhancing {len(files)} images ({args.weights} weights) -> {args.out_dir}")
    for f in files:
        img = _load_rgb01(osp.join(args.in_dir, f))
        h, w = img.shape[:2]; m = args.pad
        ph, pw = (m - h % m) % m, (m - w % m) % m
        x = np.pad(img, ((0, ph), (0, pw), (0, 0)), mode="reflect")
        t = torch.from_numpy(x.transpose(2, 0, 1)).unsqueeze(0).float().to(args.device)
        with torch.no_grad():
            out = model(t)["rgb"][0].cpu().clamp(0, 1).numpy().transpose(1, 2, 0)
        imageio.imwrite(osp.join(args.out_dir, f), (out[:h, :w] * 255).round().astype(np.uint8))
    print("Done.")


if __name__ == "__main__":
    main()
