# CCD-Net (best version) — Color-Consistent Decoupling Network

Low-light image enhancement **without colour shift**. Samsung PRISM 25VI25TU.

## Read this first — the two colour spaces (NOT in conflict)

| | CIELAB (Lab) | HVI / YCbCr |
|---|---|---|
| Role | **Measuring** colour error | **Processing** the image in the network |
| Used in | the **loss** (DeltaE term) + the **metric** (DeltaE2000, LAB-RMSE) | the **network** (splits brightness vs colour) |
| In the model? | **No** — never enhanced in Lab | **Yes** — the network's working space |

The network works in **HVI** (default) or **YCbCr**; we only *score/penalise* colour in **CIELAB**. They reinforce each other.

## What changed vs the first run (and why)
The first run (YCbCr, 30k iters) already **beat DCC-Net on colour** (DeltaE2000 9.58 vs 12.10) and PSNR, but **lost SSIM** because the loss was ~97% colour, and AMP made the DeltaE loss NaN. This version fixes all of that:

- **Colour space = learnable HVI** by default (CVPR'25, purpose-built for colour fidelity). One-line switch to YCbCr for ablation A1.
- **Loss rebalanced** (w_ssim 0.2->1.0, w_color 0.5->0.05, + VGG perceptual) so structure is properly optimised — fixes the SSIM gap.
- **All loss terms computed in fp32** (Lab/DeltaE guarded with clamps) -> AMP can never NaN again. Default is fp32 anyway.
- **EMA of weights** -> smoother, better final model; validation + the saved model use EMA.
- **Warmup -> cosine LR**, **gradient clipping**, **non-finite-loss guard** (bad batches skipped).
- **Bigger** (base=64, ~10.8M params) — still small; tune down to 48/32 if you see overfitting.

## Install
    pip install -r requirements.txt    # torch, torchvision, scikit-image, imageio, pandas, pyyaml
    # optional (LPIPS/NIQE in evaluate.py): pip install pyiqa

## Data layout (LOL-v1)
    dataset/LOLv1/our485/{low,high}   # 485 train pairs
    dataset/LOLv1/eval15/{low,high}   #  15 test pairs
Edit paths in configs/ccdnet_best.yaml.

## Train -> Infer -> Evaluate
    # train (HVI). Resume with --resume experiments/<name>/checkpoints/latest.pth
    python train.py --config configs/ccdnet_best.yaml --device cuda

    # enhance eval15 (loads EMA weights by default)
    python infer.py --ckpt experiments/ccdnet_best_hvi/checkpoints/best.pth \
        --in-dir dataset/LOLv1/eval15/low --out-dir results/ccdnet --color-space hvi --base-channels 64

    # score with the harness (same tool for every method)
    python evaluate.py eval --gt-dir dataset/LOLv1/eval15/high --pred-dir results/ccdnet --name ccdnet --out-dir bench
    # fair comparison vs DCC-Net (paired Wilcoxon):
    python evaluate.py compare --csv-dir bench --reference dccnet --metric DeltaE2000

## Recommended experiments (you have the GPU for it)
1. Main run: configs/ccdnet_best.yaml (HVI).
2. Ablation A1 (colour space): also run configs/ccdnet_best_ycbcr.yaml; compare DeltaE2000.
3. Ablation A2 (colour loss): set loss.w_color: 0.0 vs 0.05.
4. Ablation A5 (weight sweep): w_color in {0.02, 0.05, 0.1} — find the DeltaE/SSIM sweet spot.
5. Ablation A4 (denoiser): model.use_lowrank: true vs false.

## Files
    ccdnet/color_space.py  RGB<->YCbCr, learnable RGB<->HVI, guarded RGB->Lab + deltaE76 (loss)
    ccdnet/model.py        CCDNet: LumaNet, ChromaNet, CrossChannelAttention, SFT
    ccdnet/losses.py       fp32-safe Charbonnier + (1-SSIM) + DeltaE76 + L1(luma) + VGG
    ccdnet/data.py         PairedLowLightDataset
    train.py / infer.py    training (EMA, warmup+cosine, guard, resume) / inference (EMA)
    evaluate.py            canonical harness (eval + compare)
    configs/ccdnet_best.yaml          (HVI, default)
    configs/ccdnet_best_ycbcr.yaml    (YCbCr, ablation A1)

## Honest note
The design is built and validated to run and is measured fairly, but whether it
beats DCC-Net on EVERY metric is empirical. The defensible target is
better DeltaE2000 (colour KPI) at comparable PSNR/SSIM — exactly what
"enhancement without colour shift" means.
