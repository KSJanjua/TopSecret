#!/usr/bin/env python3
"""
CCD-Net training (best version).

Upgrades over the first run, all driven by what we observed:
  * Loss rebalanced (color no longer dominates) + computed in fp32 (AMP-safe).
  * Warmup -> cosine LR schedule (stable start, smooth decay).
  * EMA (exponential moving average) of weights -> better, smoother final model;
    validation and the saved best/latest use the EMA model.
  * Non-finite-loss guard: any batch producing NaN/Inf is skipped, so one bad
    batch can never poison the whole run.
  * Best model selected by DeltaE2000 (the KPI). Same metric fns as evaluate.py.

Usage:
  python train.py --config configs/ccdnet_best.yaml --device cuda
  python train.py --config configs/ccdnet_best.yaml --resume experiments/<name>/checkpoints/latest.pth
"""
from __future__ import annotations

import argparse, csv, math, os, os.path as osp, random, time
from copy import deepcopy

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

from ccdnet import build_ccdnet, CCDLoss
from ccdnet.data import PairedLowLightDataset
from evaluate import psnr_rgb, psnr_y, ssim_canonical, delta_e2000, lab_rmse


# --------------------------------------------------------------------------
def seed_everything(seed):
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True      # speed (inputs are fixed-size crops)


def infinite(loader):
    while True:
        for b in loader:
            yield b


def to_np(t):
    return t.detach().cpu().float().clamp(0, 1).numpy().transpose(1, 2, 0)


def append_csv(path, row):
    new = not osp.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(row.keys()))
        if new:
            w.writeheader()
        w.writerow(row)


def lr_at(it, warmup, total, base_lr, min_lr=1e-6):
    if it <= warmup:
        return base_lr * it / max(1, warmup)
    t = (it - warmup) / max(1, total - warmup)
    return min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * t))


class ModelEMA:
    """Exponential moving average of model weights."""
    def __init__(self, model, decay=0.9999):
        self.ema = deepcopy(model).eval()
        for p in self.ema.parameters():
            p.requires_grad_(False)
        self.decay = decay

    @torch.no_grad()
    def update(self, model):
        for e, m in zip(self.ema.state_dict().values(), model.state_dict().values()):
            if e.dtype.is_floating_point:
                e.mul_(self.decay).add_(m.detach().to(e.dtype), alpha=1 - self.decay)
            else:
                e.copy_(m)


@torch.no_grad()
def validate(model, val_loader, device):
    model.eval()
    acc = {k: [] for k in ["PSNR_RGB", "PSNR_Y", "SSIM", "DeltaE2000", "LAB_RMSE"]}
    for b in val_loader:
        out = model(b["lq"].to(device))
        for i in range(b["lq"].shape[0]):
            pred, gt = to_np(out["rgb"][i]), to_np(b["gt"][i])
            acc["PSNR_RGB"].append(psnr_rgb(pred, gt))
            acc["PSNR_Y"].append(psnr_y(pred, gt))
            acc["SSIM"].append(ssim_canonical(pred, gt))
            acc["DeltaE2000"].append(delta_e2000(pred, gt))
            acc["LAB_RMSE"].append(lab_rmse(pred, gt))
    return {k: float(np.mean(v)) for k, v in acc.items()}


def save_ckpt(path, model, ema, opt, it, best):
    torch.save({"model": model.state_dict(), "ema": ema.ema.state_dict(),
                "opt": opt.state_dict(), "iter": it, "best": best}, path)


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--resume", default=None)
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config))
    tr, mc, lc = cfg["train"], cfg["model"], cfg["loss"]
    seed_everything(cfg.get("seed", 42))
    device = args.device
    mc = {**mc, "color_space": cfg.get("color_space", "hvi")}

    exp = osp.join("experiments", cfg["name"]); ckpt = osp.join(exp, "checkpoints")
    os.makedirs(ckpt, exist_ok=True)
    yaml.safe_dump(cfg, open(osp.join(exp, "config_used.yaml"), "w"))

    # data
    train_ds = PairedLowLightDataset(tr["lq_dir"], tr["gt_dir"], crop_size=tr["crop_size"],
                                     train=True, use_flip=tr.get("use_flip", True),
                                     use_rot=tr.get("use_rot", True))
    train_loader = DataLoader(train_ds, batch_size=tr["batch_size"], shuffle=True,
                              num_workers=tr.get("num_workers", 8), drop_last=True,
                              pin_memory=(device != "cpu"),
                              persistent_workers=(tr.get("num_workers", 8) > 0),
                              prefetch_factor=4 if tr.get("num_workers", 8) > 0 else None)
    val_ds = PairedLowLightDataset(cfg["eval"]["gt_dir"].replace("/high", "/low"),
                                   cfg["eval"]["gt_dir"], crop_size=0, train=False)
    val_loader = DataLoader(val_ds, batch_size=1, shuffle=False, num_workers=2)

    # model / loss / optim / ema
    model = build_ccdnet(mc).to(device)
    crit = CCDLoss(**lc).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=tr["lr"],
                            betas=tuple(tr.get("betas", [0.9, 0.99])),
                            weight_decay=tr.get("weight_decay", 0.0))
    ema = ModelEMA(model, decay=tr.get("ema_decay", 0.9999))
    use_amp = bool(tr.get("amp", False)) and device != "cpu"
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

    start_it, best, n_skip = 0, float("inf"), 0
    if args.resume and osp.exists(args.resume):
        ck = torch.load(args.resume, map_location=device)
        model.load_state_dict(ck["model"]); ema.ema.load_state_dict(ck["ema"])
        opt.load_state_dict(ck["opt"]); start_it = ck["iter"]; best = ck["best"]
        print(f"Resumed @ iter {start_it} (best DeltaE2000={best:.4f})")

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"CCD-Net [{mc['color_space']}] {n_params:.2f}M params | "
          f"{len(train_ds)} train, {len(val_ds)} val | amp={use_amp} | device={device}")

    warmup = tr.get("warmup", 2000)
    total = tr["iters"]
    log_freq, val_freq, ckpt_freq = tr.get("log_freq", 200), tr.get("val_freq", 2500), tr.get("ckpt_freq", 2500)
    grad_clip = tr.get("grad_clip", 1.0)

    it_data = infinite(train_loader)
    model.train(); t0 = time.time()
    for it in range(start_it + 1, total + 1):
        for g in opt.param_groups:
            g["lr"] = lr_at(it, warmup, total, tr["lr"], tr.get("min_lr", 1e-6))
        b = next(it_data)
        lq, gt = b["lq"].to(device), b["gt"].to(device)
        gt_luma = model.cs.to_components(gt)[0]

        opt.zero_grad(set_to_none=True)
        with torch.cuda.amp.autocast(enabled=use_amp):
            out = model(lq)
            loss, logs = crit(out, gt, gt_luma=gt_luma)

        if not torch.isfinite(loss):          # guard: skip bad batch
            n_skip += 1
            if n_skip <= 10 or n_skip % 50 == 0:
                print(f"  [warn] non-finite loss at iter {it}; skipped (total skipped={n_skip})")
            continue

        scaler.scale(loss).backward()
        if grad_clip > 0:
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        scaler.step(opt); scaler.update()
        ema.update(model)

        if it % log_freq == 0:
            ips = log_freq / (time.time() - t0); t0 = time.time()
            print(f"it {it:>7d}/{total} | loss {logs['total']:.4f} "
                  f"(pix {logs['pix']:.3f} ssim {logs['ssim']:.3f} color {logs['color']:.2f} "
                  f"lum {logs['lum']:.3f}{' perc %.3f' % logs['perc'] if 'perc' in logs else ''}) "
                  f"| lr {opt.param_groups[0]['lr']:.2e} | {ips:.1f} it/s")
            append_csv(osp.join(exp, "train_log.csv"), {"iter": it, "lr": opt.param_groups[0]["lr"], **logs})

        if it % val_freq == 0 or it == total:
            m = validate(ema.ema, val_loader, device)        # validate the EMA model
            model.train()
            print(f"  [val @ {it}] (EMA) DeltaE2000 {m['DeltaE2000']:.4f} | PSNR {m['PSNR_RGB']:.2f} "
                  f"| SSIM {m['SSIM']:.4f} | LAB_RMSE {m['LAB_RMSE']:.4f}")
            append_csv(osp.join(exp, "val_log.csv"), {"iter": it, **m})
            if m["DeltaE2000"] < best:
                best = m["DeltaE2000"]
                save_ckpt(osp.join(ckpt, "best.pth"), model, ema, opt, it, best)
                print(f"  -> new best (DeltaE2000={best:.4f}) saved")

        if it % ckpt_freq == 0 or it == total:
            save_ckpt(osp.join(ckpt, "latest.pth"), model, ema, opt, it, best)

    print(f"Done. Best DeltaE2000 = {best:.4f} | skipped batches = {n_skip} | checkpoints in {ckpt}")


if __name__ == "__main__":
    main()
