"""
Color-space transforms for CCD-Net.

Two ROLES, kept strictly separate:

  (1) NETWORK working space  ->  rgb_to_ycbcr / ycbcr_to_rgb   (fixed)
                             ->  RGB_HVI (HVIT/PHVIT)           (learnable, default)
      Splits the image into a brightness channel + chroma channels so the two
      branches can process them separately, then recombines to RGB.

  (2) LOSS / METRIC space    ->  rgb_to_lab + delta_e76         (CIELAB)
      Perceptually-uniform space used ONLY to penalise/measure colour error.
      Never used to enhance the image. Matches evaluate.py (DeltaE2000 / LAB-RMSE).

All tensors are (B, C, H, W), RGB / YCbCr values in [0, 1].
The Lab path is numerically guarded (clamped cube-root and sqrt) so it can never
produce NaN/Inf gradients — this is what bit us under fp16 before.
"""
from __future__ import annotations

import torch
import torch.nn as nn

_PI = 3.141592653589793


# ============================================================================
# (1a) RGB <-> YCbCr  (fixed, invertible, full-range BT.601; chroma centred 0.5)
# ============================================================================
def rgb_to_ycbcr(rgb: torch.Tensor) -> torch.Tensor:
    r, g, b = rgb[:, 0:1], rgb[:, 1:2], rgb[:, 2:3]
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = 0.5 + (-0.168736 * r - 0.331264 * g + 0.5 * b)
    cr = 0.5 + (0.5 * r - 0.418688 * g - 0.081312 * b)
    return torch.cat([y, cb, cr], dim=1)


def ycbcr_to_rgb(ycbcr: torch.Tensor) -> torch.Tensor:
    y, cb, cr = ycbcr[:, 0:1], ycbcr[:, 1:2] - 0.5, ycbcr[:, 2:3] - 0.5
    r = y + 1.402 * cr
    g = y - 0.344136 * cb - 0.714136 * cr
    b = y + 1.772 * cb
    return torch.cat([r, g, b], dim=1)


# ============================================================================
# (1b) Learnable RGB <-> HVI  (faithful to Fediory/HVI-CIDNet, CVPR'25)
# ============================================================================
class RGB_HVI(nn.Module):
    """Trainable HVI transform. density_k controls the intensity-collapse term
    color_sensitive = (sin(I*pi/2)+eps)^k. HVIT: RGB->[H,V,I]; PHVIT: [H,V,I]->RGB."""
    def __init__(self, k_init: float = 0.2):
        super().__init__()
        self.density_k = nn.Parameter(torch.full([1], float(k_init)))
        self.this_k = float(k_init)

    def HVIT(self, img: torch.Tensor) -> torch.Tensor:
        eps = 1e-8
        value = img.max(1)[0]
        img_min = img.min(1)[0]
        hue = torch.zeros_like(value)
        hue[img[:, 2] == value] = 4.0 + ((img[:, 0] - img[:, 1]) / (value - img_min + eps))[img[:, 2] == value]
        hue[img[:, 1] == value] = 2.0 + ((img[:, 2] - img[:, 0]) / (value - img_min + eps))[img[:, 1] == value]
        hue[img[:, 0] == value] = (0.0 + ((img[:, 1] - img[:, 2]) / (value - img_min + eps))[img[:, 0] == value]) % 6
        hue[img.min(1)[0] == value] = 0.0
        hue = (hue / 6.0).unsqueeze(1)
        saturation = (value - img_min) / (value + eps)
        saturation[value == 0] = 0
        saturation = saturation.unsqueeze(1)
        value = value.unsqueeze(1)

        k = self.density_k
        self.this_k = k.item()
        color_sensitive = ((value * 0.5 * _PI).sin() + eps).pow(k)
        H = color_sensitive * saturation * (2.0 * _PI * hue).cos()
        V = color_sensitive * saturation * (2.0 * _PI * hue).sin()
        return torch.cat([H, V, value], dim=1)

    def PHVIT(self, img: torch.Tensor) -> torch.Tensor:
        eps = 1e-8
        H, V, I = img[:, 0], img[:, 1], img[:, 2]
        H = torch.clamp(H, -1, 1); V = torch.clamp(V, -1, 1); I = torch.clamp(I, 0, 1)
        v = I
        color_sensitive = ((v * 0.5 * _PI).sin() + eps).pow(self.this_k)
        H = torch.clamp(H / (color_sensitive + eps), -1, 1)
        V = torch.clamp(V / (color_sensitive + eps), -1, 1)
        h = (torch.atan2(V + eps, H + eps) / (2 * _PI)) % 1
        s = torch.clamp(torch.sqrt((H ** 2 + V ** 2).clamp(min=0) + eps), 0, 1)
        v = torch.clamp(v, 0, 1)
        hi = torch.floor(h * 6.0)
        f = h * 6.0 - hi
        p = v * (1.0 - s); q = v * (1.0 - f * s); t = v * (1.0 - (1.0 - f) * s)
        r = torch.zeros_like(h); g = torch.zeros_like(h); b = torch.zeros_like(h)
        for idx, (rr, gg, bb) in enumerate([(v, t, p), (q, v, p), (p, v, t),
                                            (p, q, v), (t, p, v), (v, p, q)]):
            m = (hi == idx)
            r[m] = rr[m]; g[m] = gg[m]; b[m] = bb[m]
        return torch.stack([r, g, b], dim=1)


# ============================================================================
# (1c) Uniform interface:  to_components(rgb)->(luma1ch, chroma2ch); to_rgb(...)
# ============================================================================
class YCbCrColorSpace(nn.Module):
    name = "ycbcr"

    def to_components(self, rgb):
        ycc = rgb_to_ycbcr(rgb)
        return ycc[:, 0:1], ycc[:, 1:3]              # Y, CbCr

    def to_rgb(self, luma, chroma):
        return ycbcr_to_rgb(torch.cat([luma, chroma], dim=1)).clamp(0, 1)


class HVIColorSpace(nn.Module):
    name = "hvi"

    def __init__(self, k_init: float = 0.2):
        super().__init__()
        self.t = RGB_HVI(k_init)

    def to_components(self, rgb):
        hvi = self.t.HVIT(rgb)
        return hvi[:, 2:3], hvi[:, 0:2]              # I (intensity), HV (chroma)

    def to_rgb(self, luma, chroma):
        return self.t.PHVIT(torch.cat([chroma, luma], dim=1)).clamp(0, 1)


def get_color_space(name: str) -> nn.Module:
    name = (name or "hvi").lower()
    if name == "ycbcr":
        return YCbCrColorSpace()
    if name == "hvi":
        return HVIColorSpace()
    raise ValueError(f"unknown color_space '{name}' (use 'hvi' or 'ycbcr')")


# ============================================================================
# (2) RGB -> CIELAB (D65), numerically guarded -> used ONLY by the colour loss
# ============================================================================
_RGB2XYZ = torch.tensor(
    [[0.412453, 0.357580, 0.180423],
     [0.212671, 0.715160, 0.072169],
     [0.019334, 0.119193, 0.950227]], dtype=torch.float32)
_WHITE_D65 = torch.tensor([0.95047, 1.0, 1.08883], dtype=torch.float32)


def _srgb_to_linear(c):
    return torch.where(c <= 0.04045, c / 12.92, ((c.clamp(min=0) + 0.055) / 1.055) ** 2.4)


def rgb_to_lab(rgb: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """sRGB [0,1] (B,3,H,W) -> CIELAB (B,3,H,W). Differentiable, NaN-safe."""
    b, _, h, w = rgb.shape
    lin = _srgb_to_linear(rgb.clamp(0.0, 1.0))
    m = _RGB2XYZ.to(rgb.device, rgb.dtype)
    flat = lin.permute(0, 2, 3, 1).reshape(b, -1, 3)
    xyz = (flat @ m.T) / _WHITE_D65.to(rgb.device, rgb.dtype)
    thr = 0.008856
    xyz_safe = xyz.clamp(min=eps)                       # guard: base of cube-root > 0
    f = torch.where(xyz > thr, xyz_safe ** (1.0 / 3.0), 7.787 * xyz + 16.0 / 116.0)
    fx, fy, fz = f[..., 0], f[..., 1], f[..., 2]
    L = 116.0 * fy - 16.0
    a = 500.0 * (fx - fy)
    bb = 200.0 * (fy - fz)
    lab = torch.stack([L, a, bb], dim=-1)
    return lab.reshape(b, h, w, 3).permute(0, 3, 1, 2).contiguous()


def delta_e76(rgb_pred: torch.Tensor, rgb_gt: torch.Tensor, eps: float = 1e-4) -> torch.Tensor:
    """Mean per-pixel CIE76 colour difference in CIELAB. NaN-safe.
    Differentiable surrogate for the DeltaE2000 we *evaluate* with."""
    lab_p = rgb_to_lab(rgb_pred)
    lab_g = rgb_to_lab(rgb_gt)
    d = torch.sqrt(((lab_p - lab_g) ** 2).sum(dim=1).clamp(min=eps))   # guard: sqrt arg > 0
    return d.mean()
