"""
CCD-Net (Color-Consistent Decoupling Network) — best version.

Architecture (unchanged in spirit from the validated MVP, but deeper/wider and
fully colour-space-agnostic):

  RGB --(HVI or YCbCr)--> luma(1ch) -> LumaNet  -> luma_hat (+ multi-scale feats)
                          chroma(2ch)-> ChromaNet(guided by luma feats) -> chroma_hat
  [luma_hat, chroma_hat] --(inverse)--> RGB_hat

Colour is corrected in the decoupled space and guided by structure:
  * CrossChannelAttention (CCCA): channel (transposed) attention, O(C^2), so it is
    resolution-independent. Chroma = queries, luminance = keys/values -> chroma
    features are reorganised by image structure (learnable + local replacement for
    DCC-Net's fixed Dual Affinity Matrix).
  * SFT modulation at each decoder scale: luminance features predict (gamma, beta)
    that affine-modulate chroma features.

Returns {rgb, luma, chroma} (+ y/cbcr aliases) so the loss can supervise both.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .color_space import get_color_space


# ---------------------------------------------------------------------------
# blocks
# ---------------------------------------------------------------------------
class ChannelAttention(nn.Module):
    def __init__(self, ch, r=8):
        super().__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(ch, max(ch // r, 4), 1), nn.ReLU(inplace=True),
            nn.Conv2d(max(ch // r, 4), ch, 1), nn.Sigmoid())

    def forward(self, x):
        return x * self.fc(x)


class ResBlock(nn.Module):
    def __init__(self, ch, use_ca=True):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(ch, ch, 3, 1, 1), nn.GELU(),
            nn.Conv2d(ch, ch, 3, 1, 1))
        self.ca = ChannelAttention(ch) if use_ca else nn.Identity()

    def forward(self, x):
        return x + self.ca(self.body(x))


def make_blocks(ch, n, use_ca=True):
    return nn.Sequential(*[ResBlock(ch, use_ca) for _ in range(max(n, 1))])


class LowRankDenoise(nn.Module):
    """Optional LSDB-inspired low-rank channel denoiser (default off)."""
    def __init__(self, ch, rank_ratio=0.5):
        super().__init__()
        r = max(int(ch * rank_ratio), 4)
        self.feat = nn.Conv2d(ch, ch, 3, 1, 1)
        self.down = nn.Conv2d(ch, r, 1)
        self.act = nn.GELU()
        self.up = nn.Conv2d(r, ch, 1)

    def forward(self, x):
        return x + self.up(self.act(self.down(self.feat(x))))


class Down(nn.Module):
    def __init__(self, i, o):
        super().__init__(); self.c = nn.Conv2d(i, o, 3, 2, 1)

    def forward(self, x):
        return self.c(x)


class Up(nn.Module):
    def __init__(self, i, o):
        super().__init__(); self.c = nn.Conv2d(i, o, 3, 1, 1)

    def forward(self, x, size):
        return self.c(F.interpolate(x, size=size, mode="bilinear", align_corners=False))


class SFT(nn.Module):
    """Spatial Feature Transform: `cond` (luma) predicts (gamma,beta) to modulate x."""
    def __init__(self, x_ch, cond_ch):
        super().__init__()
        self.shared = nn.Sequential(nn.Conv2d(cond_ch, x_ch, 1), nn.GELU())
        self.gamma = nn.Conv2d(x_ch, x_ch, 1)
        self.beta = nn.Conv2d(x_ch, x_ch, 1)

    def forward(self, x, cond):
        if cond.shape[-2:] != x.shape[-2:]:
            cond = F.interpolate(cond, size=x.shape[-2:], mode="bilinear", align_corners=False)
        h = self.shared(cond)
        return x * (1 + self.gamma(h)) + self.beta(h)


class CrossChannelAttention(nn.Module):
    """Colour<->Content cross-attention over CHANNELS (Restormer/MST-style)."""
    def __init__(self, x_ch, cond_ch, heads=4):
        super().__init__()
        self.heads = heads
        self.q = nn.Conv2d(x_ch, x_ch, 1)
        self.k = nn.Conv2d(cond_ch, x_ch, 1)
        self.v = nn.Conv2d(cond_ch, x_ch, 1)
        self.proj = nn.Conv2d(x_ch, x_ch, 1)
        self.temp = nn.Parameter(torch.ones(heads, 1, 1))

    def forward(self, x, cond):
        if cond.shape[-2:] != x.shape[-2:]:
            cond = F.interpolate(cond, size=x.shape[-2:], mode="bilinear", align_corners=False)
        b, c, h, w = x.shape
        q = self.q(x).reshape(b, self.heads, c // self.heads, h * w)
        k = self.k(cond).reshape(b, self.heads, c // self.heads, h * w)
        v = self.v(cond).reshape(b, self.heads, c // self.heads, h * w)
        q = F.normalize(q, dim=-1); k = F.normalize(k, dim=-1)
        attn = (q @ k.transpose(-2, -1)) * self.temp
        attn = attn.softmax(dim=-1)
        return x + self.proj((attn @ v).reshape(b, c, h, w))


# ---------------------------------------------------------------------------
# luminance branch
# ---------------------------------------------------------------------------
class LumaNet(nn.Module):
    def __init__(self, base=64, n_blocks=2, use_lowrank=False):
        super().__init__()
        c0, c1, c2 = base, base * 2, base * 4
        self.in_conv = nn.Conv2d(1, c0, 3, 1, 1)
        self.enc0 = make_blocks(c0, n_blocks)
        self.down0 = Down(c0, c1)
        self.enc1 = make_blocks(c1, n_blocks)
        self.down1 = Down(c1, c2)
        bott = [make_blocks(c2, n_blocks)]
        if use_lowrank:
            bott.append(LowRankDenoise(c2))
        bott.append(make_blocks(c2, 1))
        self.bott = nn.Sequential(*bott)
        self.up1 = Up(c2, c1); self.fuse1 = nn.Conv2d(c1 * 2, c1, 1); self.dec1 = make_blocks(c1, n_blocks)
        self.up0 = Up(c1, c0); self.fuse0 = nn.Conv2d(c0 * 2, c0, 1); self.dec0 = make_blocks(c0, n_blocks)
        self.out_conv = nn.Conv2d(c0, 1, 3, 1, 1)

    def forward(self, y):
        x0 = self.enc0(self.in_conv(y))
        x1 = self.enc1(self.down0(x0))
        xb = self.bott(self.down1(x1))
        d1 = self.dec1(self.fuse1(torch.cat([self.up1(xb, x1.shape[-2:]), x1], 1)))
        d0 = self.dec0(self.fuse0(torch.cat([self.up0(d1, x0.shape[-2:]), x0], 1)))
        y_hat = (y + self.out_conv(d0)).clamp(0.0, 1.0)
        return y_hat, {"s2": xb, "s1": d1, "s0": d0}


# ---------------------------------------------------------------------------
# chroma branch (guided by luma feats)
# ---------------------------------------------------------------------------
class ChromaNet(nn.Module):
    def __init__(self, base=64, n_blocks=2):
        super().__init__()
        c0, c1, c2 = base, base * 2, base * 4
        self.in_conv = nn.Conv2d(2, c0, 3, 1, 1)
        self.enc0 = make_blocks(c0, n_blocks, use_ca=False)
        self.down0 = Down(c0, c1)
        self.enc1 = make_blocks(c1, n_blocks, use_ca=False)
        self.down1 = Down(c1, c2)
        self.bott = make_blocks(c2, n_blocks, use_ca=False)
        self.ccca = CrossChannelAttention(c2, c2)
        self.up1 = Up(c2, c1); self.fuse1 = nn.Conv2d(c1 * 2, c1, 1)
        self.sft1 = SFT(c1, c1); self.dec1 = make_blocks(c1, n_blocks, use_ca=False)
        self.up0 = Up(c1, c0); self.fuse0 = nn.Conv2d(c0 * 2, c0, 1)
        self.sft0 = SFT(c0, c0); self.dec0 = make_blocks(c0, n_blocks, use_ca=False)
        self.out_conv = nn.Conv2d(c0, 2, 3, 1, 1)

    def forward(self, chroma, luma):
        x0 = self.enc0(self.in_conv(chroma))
        x1 = self.enc1(self.down0(x0))
        xb = self.ccca(self.bott(self.down1(x1)), luma["s2"])
        u1 = self.fuse1(torch.cat([self.up1(xb, x1.shape[-2:]), x1], 1))
        d1 = self.dec1(self.sft1(u1, luma["s1"]))
        u0 = self.fuse0(torch.cat([self.up0(d1, x0.shape[-2:]), x0], 1))
        d0 = self.dec0(self.sft0(u0, luma["s0"]))
        return chroma + self.out_conv(d0)            # residual; range handled by color space


# ---------------------------------------------------------------------------
# full model
# ---------------------------------------------------------------------------
class CCDNet(nn.Module):
    def __init__(self, base=64, n_blocks=2, use_lowrank=False, color_space="hvi"):
        super().__init__()
        self.cs = get_color_space(color_space)
        self.color_space = color_space
        self.luma = LumaNet(base, n_blocks, use_lowrank)
        self.chroma = ChromaNet(base, n_blocks)

    def forward(self, rgb):
        luma_in, chroma_in = self.cs.to_components(rgb)
        luma_hat, feats = self.luma(luma_in)
        chroma_hat = self.chroma(chroma_in, feats)
        rgb_hat = self.cs.to_rgb(luma_hat, chroma_hat)
        return {"rgb": rgb_hat, "luma": luma_hat, "chroma": chroma_hat,
                "y": luma_hat, "cbcr": chroma_hat}


def build_ccdnet(cfg=None):
    cfg = cfg or {}
    return CCDNet(base=cfg.get("base_channels", 64),
                  n_blocks=cfg.get("n_blocks", 2),
                  use_lowrank=cfg.get("use_lowrank", False),
                  color_space=cfg.get("color_space", "hvi"))
