"""
CCD-Net composite loss (best version).

  L = w_pix  * Charbonnier(RGB)
    + w_ssim * (1 - SSIM(RGB))
    + w_color* DeltaE76(Lab)        <- explicit colour term (in CIELAB)
    + w_lum  * L1(luma_hat, luma_gt)
    + w_perc * VGG(RGB)             <- optional perceptual

Numerical safety: the whole loss is computed in float32 (inputs cast up). Under
AMP the network runs in fp16 for speed, but every loss term — especially the
Lab / DeltaE path — is fp32, so the NaN explosions we hit before cannot recur.
The colour term lives in the same CIELAB space evaluate.py scores with.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .color_space import rgb_to_ycbcr, delta_e76


class CharbonnierLoss(nn.Module):
    def __init__(self, eps=1e-6):
        super().__init__(); self.eps2 = eps * eps

    def forward(self, x, y):
        return torch.mean(torch.sqrt((x - y) ** 2 + self.eps2))


def _gauss_win(ch, ksize=11, sigma=1.5, device="cpu", dtype=torch.float32):
    coords = torch.arange(ksize, device=device, dtype=dtype) - (ksize - 1) / 2
    g = torch.exp(-(coords ** 2) / (2 * sigma ** 2)); g = (g / g.sum()).unsqueeze(0)
    win = (g.T @ g)
    return win.expand(ch, 1, ksize, ksize).contiguous()


class SSIM(nn.Module):
    def __init__(self, ksize=11, sigma=1.5, data_range=1.0):
        super().__init__()
        self.ksize, self.sigma = ksize, sigma
        self.C1 = (0.01 * data_range) ** 2
        self.C2 = (0.03 * data_range) ** 2

    def forward(self, x, y):
        ch = x.shape[1]; pad = self.ksize // 2
        win = _gauss_win(ch, self.ksize, self.sigma, x.device, x.dtype)
        mx = F.conv2d(x, win, padding=pad, groups=ch)
        my = F.conv2d(y, win, padding=pad, groups=ch)
        mx2, my2, mxy = mx * mx, my * my, mx * my
        sx = F.conv2d(x * x, win, padding=pad, groups=ch) - mx2
        sy = F.conv2d(y * y, win, padding=pad, groups=ch) - my2
        sxy = F.conv2d(x * y, win, padding=pad, groups=ch) - mxy
        ssim_map = ((2 * mxy + self.C1) * (2 * sxy + self.C2)) / \
                   ((mx2 + my2 + self.C1) * (sx + sy + self.C2))
        return ssim_map.mean()


class VGGPerceptual(nn.Module):
    def __init__(self):
        super().__init__()
        from torchvision.models import vgg19, VGG19_Weights
        feats = vgg19(weights=VGG19_Weights.IMAGENET1K_V1).features
        self.slices = nn.ModuleList([feats[:2], feats[2:7], feats[7:12], feats[12:21]])
        for p in self.parameters():
            p.requires_grad = False
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))
        self.w = [1 / 8, 1 / 4, 1 / 2, 1.0]

    def forward(self, x, y):
        x = (x - self.mean) / self.std
        y = (y - self.mean) / self.std
        loss, a, b = 0.0, x, y
        for sl, w in zip(self.slices, self.w):
            a, b = sl(a), sl(b)
            loss = loss + w * F.l1_loss(a, b.detach())
        return loss


class CCDLoss(nn.Module):
    def __init__(self, w_pix=1.0, w_ssim=1.0, w_color=0.05, w_lum=0.5, w_perc=0.1):
        super().__init__()
        self.w = dict(pix=w_pix, ssim=w_ssim, color=w_color, lum=w_lum, perc=w_perc)
        self.charb = CharbonnierLoss()
        self.ssim = SSIM()
        self.vgg = VGGPerceptual() if w_perc > 0 else None

    def forward(self, out, gt_rgb, gt_luma=None):
        # everything in fp32 -> AMP-safe
        rgb = out["rgb"].float()
        gt = gt_rgb.float()
        luma_hat = out.get("luma", out.get("y")).float()
        y_gt = (gt_luma.float() if gt_luma is not None else rgb_to_ycbcr(gt)[:, 0:1])

        l_pix = self.charb(rgb, gt)
        l_ssim = 1.0 - self.ssim(rgb, gt)
        l_color = delta_e76(rgb, gt)
        l_lum = F.l1_loss(luma_hat, y_gt)
        total = (self.w["pix"] * l_pix + self.w["ssim"] * l_ssim
                 + self.w["color"] * l_color + self.w["lum"] * l_lum)
        logs = {"pix": l_pix.item(), "ssim": l_ssim.item(),
                "color": l_color.item(), "lum": l_lum.item()}
        if self.vgg is not None:
            l_perc = self.vgg(rgb, gt)
            total = total + self.w["perc"] * l_perc
            logs["perc"] = l_perc.item()
        logs["total"] = total.item()
        return total, logs
